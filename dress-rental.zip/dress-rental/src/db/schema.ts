// DB 구조. 표 하나하나의 설명은 docs/DB.md 참고.
// 구조를 바꾸면: npm run db:generate → npm run db:migrate
import {
  pgTable,
  pgEnum,
  text,
  integer,
  boolean,
  timestamp,
  date,
  numeric,
  jsonb,
  primaryKey,
  uniqueIndex,
  index,
} from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

const id = () =>
  text('id')
    .primaryKey()
    .$defaultFn(() => crypto.randomUUID());
const createdAt = () => timestamp('created_at', { withTimezone: true }).notNull().defaultNow();

export const authProvider = pgEnum('auth_provider', ['KAKAO', 'EMAIL']);
export const dressType = pgEnum('dress_type', ['MERMAID', 'ALINE', 'BALLGOWN', 'MINI']);
// BANK=계좌이체(국내) STORE=스마트스토어 예약금(국내) PAYPAL=PayPal(해외)
export const payMethod = pgEnum('pay_method', ['BANK', 'STORE', 'PAYPAL']);
// PENDING=결제 대기 CONFIRMED=확정 COMPLETED=대여 끝 CANCELLED=취소 EXPIRED=기한 지나 자동 취소
export const reservationStatus = pgEnum('reservation_status', [
  'PENDING',
  'CONFIRMED',
  'COMPLETED',
  'CANCELLED',
  'EXPIRED',
]);
// REFUND_NEEDED=결제된 예약이 취소됨(환불 처리 필요) VOID=결제 전에 취소/만료
export const paymentStatus = pgEnum('payment_status', ['PENDING', 'PAID', 'REFUND_NEEDED', 'REFUNDED', 'VOID']);

export const users = pgTable('users', {
  id: id(),
  email: text('email').unique(),
  kakaoId: text('kakao_id').unique(),
  name: text('name'),
  provider: authProvider('provider').notNull(),
  createdAt: createdAt(),
});

// 이메일 인증번호. 번호 자체는 저장하지 않고 해시만 저장.
export const emailCodes = pgTable(
  'email_codes',
  {
    id: id(),
    email: text('email').notNull(),
    codeHash: text('code_hash').notNull(),
    expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
    attempts: integer('attempts').notNull().default(0),
    usedAt: timestamp('used_at', { withTimezone: true }),
    createdAt: createdAt(),
  },
  (t) => [index('email_codes_email_idx').on(t.email, t.createdAt)],
);

export const dresses = pgTable('dresses', {
  id: id(),
  code: text('code').notNull().unique(), // 화면 표시 번호 (No. 01)
  nameKo: text('name_ko').notNull(),
  nameEn: text('name_en').notNull(),
  type: dressType('type').notNull(),
  sizes: text('sizes').array().notNull(), // ["44","55","66"]
  priceKrw: integer('price_krw').notNull(),
  imageUrl: text('image_url'),
  active: boolean('active').notNull().default(true),
  sortOrder: integer('sort_order').notNull().default(0),
  createdAt: createdAt(),
});

export const shoes = pgTable('shoes', {
  id: id(),
  nameKo: text('name_ko').notNull(),
  nameEn: text('name_en').notNull(),
  heelCm: integer('heel_cm').notNull(),
  priceKrw: integer('price_krw').notNull(),
  imageUrl: text('image_url'),
  active: boolean('active').notNull().default(true),
  sortOrder: integer('sort_order').notNull().default(0),
});

// 신발 사이즈별 보유 수량
export const shoeStocks = pgTable(
  'shoe_stocks',
  {
    id: id(),
    shoeId: text('shoe_id')
      .notNull()
      .references(() => shoes.id, { onDelete: 'cascade' }),
    size: integer('size').notNull(), // mm
    quantity: integer('quantity').notNull(),
  },
  (t) => [uniqueIndex('shoe_stocks_shoe_size_uq').on(t.shoeId, t.size)],
);

export const reservations = pgTable(
  'reservations',
  {
    id: id(),
    code: text('code').notNull().unique(), // 고객용 예약번호 R1007-K3F9QX
    userId: text('user_id')
      .notNull()
      .references(() => users.id),
    fittingAt: timestamp('fitting_at', { withTimezone: true }).notNull(),
    fittingDate: date('fitting_date', { mode: 'string' }).notNull(), // 한국 날짜 YYYY-MM-DD
    dressId: text('dress_id')
      .notNull()
      .references(() => dresses.id),
    dressSize: text('dress_size').notNull(),
    shoeId: text('shoe_id').references(() => shoes.id),
    shoeSize: integer('shoe_size'),
    payMethod: payMethod('pay_method').notNull(),
    amountKrw: integer('amount_krw').notNull(), // 서버가 계산한 금액
    status: reservationStatus('status').notNull().default('PENDING'),
    dueAt: timestamp('due_at', { withTimezone: true }).notNull(), // 결제 기한
    locale: text('locale').notNull().default('ko'),
    adminMemo: text('admin_memo'),
    confirmedAt: timestamp('confirmed_at', { withTimezone: true }),
    cancelledAt: timestamp('cancelled_at', { withTimezone: true }),
    createdAt: createdAt(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (t) => [
    index('reservations_status_due_idx').on(t.status, t.dueAt),
    index('reservations_date_idx').on(t.fittingDate),
    index('reservations_user_idx').on(t.userId),
  ],
);

// ── 중복 예약 방지 잠금 ────────────────────────────────────
// 활성 예약(PENDING/CONFIRMED)만 행을 가짐. 취소·만료되면 행을 지움.
// 기본키가 겹치면 DB가 INSERT를 거부 → 동시에 눌러도 한 명만 성공.

// 한 시간대 = 한 팀
export const slotLocks = pgTable('slot_locks', {
  fittingAt: timestamp('fitting_at', { withTimezone: true }).primaryKey(),
  reservationId: text('reservation_id')
    .notNull()
    .unique()
    .references(() => reservations.id, { onDelete: 'cascade' }),
});

// 드레스 × 날짜 (예약일 ± DRESS_BUFFER_DAYS 만큼 행 생성)
export const dressDayLocks = pgTable(
  'dress_day_locks',
  {
    dressId: text('dress_id')
      .notNull()
      .references(() => dresses.id, { onDelete: 'cascade' }),
    day: date('day', { mode: 'string' }).notNull(),
    reservationId: text('reservation_id')
      .notNull()
      .references(() => reservations.id, { onDelete: 'cascade' }),
  },
  (t) => [primaryKey({ name: 'dress_day_locks_pk', columns: [t.dressId, t.day] }), index('dress_day_locks_resv_idx').on(t.reservationId)],
);

export const payments = pgTable(
  'payments',
  {
    id: id(),
    reservationId: text('reservation_id')
      .notNull()
      .references(() => reservations.id, { onDelete: 'cascade' }),
    method: payMethod('method').notNull(),
    status: paymentStatus('status').notNull().default('PENDING'),
    amount: numeric('amount', { precision: 12, scale: 2 }).notNull(),
    currency: text('currency').notNull().default('KRW'), // KRW 또는 USD
    externalId: text('external_id').unique(), // PayPal 주문번호 등
    payerName: text('payer_name'), // 입금자명
    note: text('note'),
    raw: jsonb('raw'), // PayPal 응답 원본
    paidAt: timestamp('paid_at', { withTimezone: true }),
    createdAt: createdAt(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (t) => [index('payments_resv_idx').on(t.reservationId)],
);

// 쇼룸 휴무일
export const closedDays = pgTable('closed_days', {
  day: date('day', { mode: 'string' }).primaryKey(),
  reason: text('reason'),
});

export const reservationsRelations = relations(reservations, ({ one, many }) => ({
  user: one(users, { fields: [reservations.userId], references: [users.id] }),
  dress: one(dresses, { fields: [reservations.dressId], references: [dresses.id] }),
  shoe: one(shoes, { fields: [reservations.shoeId], references: [shoes.id] }),
  payments: many(payments),
}));
export const paymentsRelations = relations(payments, ({ one }) => ({
  reservation: one(reservations, { fields: [payments.reservationId], references: [reservations.id] }),
}));
export const shoesRelations = relations(shoes, ({ many }) => ({ stocks: many(shoeStocks) }));
export const shoeStocksRelations = relations(shoeStocks, ({ one }) => ({
  shoe: one(shoes, { fields: [shoeStocks.shoeId], references: [shoes.id] }),
}));
export const usersRelations = relations(users, ({ many }) => ({ reservations: many(reservations) }));

export type Reservation = typeof reservations.$inferSelect;
export type Dress = typeof dresses.$inferSelect;
export type Shoe = typeof shoes.$inferSelect;
export type Payment = typeof payments.$inferSelect;
export type PayMethod = (typeof payMethod.enumValues)[number];
export type ReservationStatus = (typeof reservationStatus.enumValues)[number];
export type DressType = (typeof dressType.enumValues)[number];
