// 사업장 정보. 실제 값으로 바꾸세요.
export const site = {
  brand: '[BRAND]',
  managerKo: '[담당자명] 실장',
  managerEn: '[Name]',
  phone: '[전화번호]',
  phoneHref: 'tel:000-0000-0000',
  kakaoChannel: '[카카오톡 채널명]',
  hoursKo: '[운영 시간]',
  hoursEn: '[Opening hours] (KST)',
  addressKo: '[쇼룸 주소]',
  addressEn: '[Showroom address]',
  // 홈 화면 큰 사진 (public/ 폴더에 넣고 '/hero-1.jpg' 처럼 적기). 비우면 회색 자리표시.
  heroImages: ['', ''],
};
