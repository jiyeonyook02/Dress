import 'server-only';
import { eq } from 'drizzle-orm';
import { db, schema } from '@/db';
import { sendMail } from './mail';
import { bank, SITE_URL } from './config';
import { fmtKst, kstTime, fmtDay } from './dates';

/** 예약 접수 / 확정 메일. 이메일이 없는 회원(카카오 이메일 미동의)은 건너뜀. 실패해도 예약은 유지. */
export async function notifyReservation(reservationId: string, kind: 'created' | 'confirmed') {
  try {
    const r = await db.query.reservations.findFirst({
      where: eq(schema.reservations.id, reservationId),
      with: { user: true, dress: true, payments: true },
    });
    if (!r?.user.email) return;
    const en = r.locale === 'en';
    const when = `${fmtDay(r.fittingDate)} ${kstTime(r.fittingAt)}`;
    const link = `${SITE_URL}/book/done/${r.code}`;
    let subject: string;
    let body: string;
    if (kind === 'created') {
      subject = en ? `Reservation received (${r.code})` : `예약 접수 안내 (${r.code})`;
      const howToPay =
        r.payMethod === 'BANK'
          ? `${bank.name} ${bank.account} (${bank.holder})`
          : en
            ? `See payment details: ${link}`
            : `결제 안내: ${link}`;
      body = en
        ? `Fitting: ${when} (KST)\nReservation: ${r.code}\nPay by: ${fmtKst(r.dueAt)} (KST)\n${howToPay}\n\nUnpaid bookings are cancelled after the deadline.`
        : `피팅: ${when}\n예약번호: ${r.code}\n결제 기한: ${fmtKst(r.dueAt)}\n${howToPay}\n입금자명 뒤에 예약번호를 적어 주세요.\n\n기한 내 미결제 시 자동 취소됩니다.`;
    } else {
      subject = en ? `Booking confirmed (${r.code})` : `예약 확정 안내 (${r.code})`;
      body = en
        ? `Your fitting on ${when} (KST) is confirmed.\nDress: ${r.dress.code} · ${r.dressSize}\nSee you at the showroom.`
        : `${when} 피팅 예약이 확정되었습니다.\n드레스: ${r.dress.code} · ${r.dressSize}\n쇼룸에서 뵙겠습니다.`;
    }
    await sendMail(r.user.email, subject, body);
  } catch (e) {
    console.error('notify failed', e);
  }
}
