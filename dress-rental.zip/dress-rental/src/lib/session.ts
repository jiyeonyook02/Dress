import 'server-only';
import { cookies } from 'next/headers';
import { SignJWT, jwtVerify } from 'jose';
import { eq } from 'drizzle-orm';
import { db, schema } from '@/db';
import { ADMIN_EMAILS } from './config';

const COOKIE = 'session';
const MAX_AGE = 60 * 60 * 24 * 30; // 30일

function secret() {
  const s = process.env.AUTH_SECRET;
  if (!s || s.length < 16) throw new Error('AUTH_SECRET 환경변수를 16자 이상으로 설정하세요');
  return new TextEncoder().encode(s);
}

export async function createSession(userId: string) {
  const token = await new SignJWT({ uid: userId })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(`${MAX_AGE}s`)
    .sign(secret());
  const jar = await cookies();
  jar.set(COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: MAX_AGE,
  });
}

export async function destroySession() {
  const jar = await cookies();
  jar.delete(COOKIE);
}

export type SessionUser = typeof schema.users.$inferSelect & { isAdmin: boolean };

export async function getUser(): Promise<SessionUser | null> {
  const jar = await cookies();
  const token = jar.get(COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret());
    const uid = typeof payload.uid === 'string' ? payload.uid : null;
    if (!uid) return null;
    const user = await db.query.users.findFirst({ where: eq(schema.users.id, uid) });
    if (!user) return null;
    return { ...user, isAdmin: !!user.email && ADMIN_EMAILS.includes(user.email.toLowerCase()) };
  } catch {
    return null;
  }
}
