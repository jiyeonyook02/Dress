// 예약 규칙과 결제 설정. 숫자는 .env 에서 바꿀 수 있음.
const num = (v: string | undefined, d: number) => (v && !Number.isNaN(Number(v)) ? Number(v) : d);

export const SITE_URL = (process.env.SITE_URL ?? 'http://localhost:3000').replace(/\/$/, '');

// 피팅 시간대 (한 시간대 = 한 팀). 바꾸려면 여기 수정.
export const SLOT_TIMES = ['11:00', '12:30', '14:00', '15:30', '17:00', '18:30'] as const;
export const SLOT_MINUTES = 60;

export const BOOKABLE_DAYS = num(process.env.BOOKABLE_DAYS, 30);
export const DRESS_BUFFER_DAYS = num(process.env.DRESS_BUFFER_DAYS, 2);
export const HOLD_HOURS = num(process.env.HOLD_HOURS, 24);

export const ADMIN_EMAILS = (process.env.ADMIN_EMAILS ?? '')
  .split(',')
  .map((s) => s.trim().toLowerCase())
  .filter(Boolean);

export const bank = {
  name: process.env.BANK_NAME ?? '',
  account: process.env.BANK_ACCOUNT ?? '',
  holder: process.env.BANK_HOLDER ?? '',
};

export const SMARTSTORE_URL = process.env.SMARTSTORE_URL ?? '';

export const paypal = {
  mode: (process.env.PAYPAL_MODE === 'api' ? 'api' : 'link') as 'api' | 'link',
  meHandle: process.env.PAYPAL_ME_HANDLE ?? '',
  env: process.env.PAYPAL_ENV === 'live' ? 'live' : 'sandbox',
  clientId: process.env.PAYPAL_CLIENT_ID ?? '',
  clientSecret: process.env.PAYPAL_CLIENT_SECRET ?? '',
  krwPerUsd: num(process.env.PAYPAL_KRW_PER_USD, 0),
};

export const kakao = {
  restApiKey: process.env.KAKAO_REST_API_KEY ?? '',
  clientSecret: process.env.KAKAO_CLIENT_SECRET ?? '',
};

export const PAY_METHODS = ['BANK', 'STORE', 'PAYPAL'] as const;
// 실제로 쓸 수 있는 결제수단 (설정이 비어 있으면 화면에서 숨김)
export function enabledPayMethods() {
  return {
    BANK: Boolean(bank.account),
    STORE: Boolean(SMARTSTORE_URL),
    PAYPAL: paypal.krwPerUsd > 0 && (paypal.mode === 'api' ? Boolean(paypal.clientId && paypal.clientSecret) : Boolean(paypal.meHandle)),
  };
}
