import 'server-only';
import { randomInt } from 'crypto';
import { and, asc, between, eq, gte, inArray, lt, sql } from 'drizzle-orm';
import { z } from 'zod';
import { db, schema, type Tx } from '@/db';
import {
  BOOKABLE_DAYS,
  DRESS_BUFFER_DAYS,
  HOLD_HOURS,
  SLOT_TIMES,
  enabledPayMethods,
  PAY_METHODS,
} from './config';
import { addDays, kstDateTime, kstTime, kstToday, DATE_RE } from './dates';
import { usdFromKrw } from './money';

const { reservations, slotLocks, dressDayLocks, payments, dresses, shoes, shoeStocks, closedDays } = schema;
const ACTIVE = ['PENDING', 'CONFIRMED'] as const;

export class BookingError extends Error {
  constructor(public code: 'SLOT' | 'DRESS' | 'SHOE' | 'INVALID' | 'CLOSED' | 'METHOD' | 'NOT_FOUND' | 'STATE') {
    super(code);
  }
}

/** 예약 가능한 날짜 범위: 내일 ~ 오늘+BOOKABLE_DAYS */
export function bookableRange(now = new Date()) {
  const today = kstToday(now);
  return { first: addDays(today, 1), last: addDays(today, BOOKABLE_DAYS) };
}

// ── 자동 만료 ────────────────────────────────────────────
/** 결제 기한이 지난 PENDING 예약을 EXPIRED로 바꾸고 잠금을 풂 */
export async function expirePending(now = new Date()) {
  return db.transaction(async (tx) => {
    const expired = await tx
      .update(reservations)
      .set({ status: 'EXPIRED', cancelledAt: now })
      .where(and(eq(reservations.status, 'PENDING'), lt(reservations.dueAt, now)))
      .returning({ id: reservations.id });
    const ids = expired.map((r) => r.id);
    if (ids.length) await releaseLocks(tx, ids, 'VOID');
    return ids.length;
  });
}

async function releaseLocks(tx: Tx, ids: string[], pendingPaymentTo: 'VOID') {
  await tx.delete(slotLocks).where(inArray(slotLocks.reservationId, ids));
  await tx.delete(dressDayLocks).where(inArray(dressDayLocks.reservationId, ids));
  await tx
    .update(payments)
    .set({ status: pendingPaymentTo })
    .where(and(inArray(payments.reservationId, ids), eq(payments.status, 'PENDING')));
}

// ── 빈자리 조회 ──────────────────────────────────────────
export async function getDaysSummary() {
  const { first, last } = bookableRange();
  const [locks, closed] = await Promise.all([
    db
      .select({ fittingAt: slotLocks.fittingAt })
      .from(slotLocks)
      .where(and(gte(slotLocks.fittingAt, kstDateTime(first, '00:00')), lt(slotLocks.fittingAt, kstDateTime(addDays(last, 1), '00:00')))),
    db.select().from(closedDays).where(between(closedDays.day, first, last)),
  ]);
  const taken = new Map<string, number>();
  for (const l of locks) {
    const day = kstToday(l.fittingAt);
    taken.set(day, (taken.get(day) ?? 0) + 1);
  }
  const closedSet = new Set(closed.map((c) => c.day));
  const days: { date: string; left: number; closed: boolean }[] = [];
  for (let d = first; d <= last; d = addDays(d, 1)) {
    days.push({ date: d, closed: closedSet.has(d), left: closedSet.has(d) ? 0 : SLOT_TIMES.length - (taken.get(d) ?? 0) });
  }
  return days;
}

export async function getAvailability(day: string) {
  if (!DATE_RE.test(day)) throw new BookingError('INVALID');
  const lo = addDays(day, -DRESS_BUFFER_DAYS);
  const hi = addDays(day, DRESS_BUFFER_DAYS);
  const [slotRows, dressRows, dressList, shoeList, stockRows, shoeUse, closed] = await Promise.all([
    db
      .select({ fittingAt: slotLocks.fittingAt })
      .from(slotLocks)
      .where(and(gte(slotLocks.fittingAt, kstDateTime(day, '00:00')), lt(slotLocks.fittingAt, kstDateTime(addDays(day, 1), '00:00')))),
    // 새 예약이 차지할 기간(day ± 버퍼) 중 하루라도 잠겨 있으면 그 드레스는 불가
    db.select({ dressId: dressDayLocks.dressId }).from(dressDayLocks).where(between(dressDayLocks.day, lo, hi)),
    db.select().from(dresses).where(eq(dresses.active, true)).orderBy(asc(dresses.sortOrder)),
    db.select().from(shoes).where(eq(shoes.active, true)).orderBy(asc(shoes.sortOrder)),
    db.select().from(shoeStocks),
    db
      .select({ shoeId: reservations.shoeId, shoeSize: reservations.shoeSize, n: sql<number>`count(*)::int` })
      .from(reservations)
      .where(and(inArray(reservations.status, [...ACTIVE]), between(reservations.fittingDate, lo, hi)))
      .groupBy(reservations.shoeId, reservations.shoeSize),
    db.select().from(closedDays).where(eq(closedDays.day, day)),
  ]);
  const takenTimes = new Set(slotRows.map((r) => kstTime(r.fittingAt)));
  const takenDresses = new Set(dressRows.map((r) => r.dressId));
  const used = new Map(shoeUse.map((u) => [`${u.shoeId}:${u.shoeSize}`, u.n]));
  const isClosed = closed.length > 0;

  return {
    date: day,
    closed: isClosed,
    slots: SLOT_TIMES.map((time) => ({ time, available: !isClosed && !takenTimes.has(time) })),
    dresses: dressList.map((d) => ({
      id: d.id,
      code: d.code,
      nameKo: d.nameKo,
      nameEn: d.nameEn,
      type: d.type,
      sizes: d.sizes,
      priceKrw: d.priceKrw,
      imageUrl: d.imageUrl,
      available: !takenDresses.has(d.id),
    })),
    shoes: shoeList.map((s) => ({
      id: s.id,
      nameKo: s.nameKo,
      nameEn: s.nameEn,
      heelCm: s.heelCm,
      priceKrw: s.priceKrw,
      imageUrl: s.imageUrl,
      sizes: stockRows
        .filter((st) => st.shoeId === s.id)
        .sort((a, b) => a.size - b.size)
        .map((st) => ({ size: st.size, left: Math.max(0, st.quantity - (used.get(`${s.id}:${st.size}`) ?? 0)) })),
    })),
  };
}

// ── 예약 만들기 ──────────────────────────────────────────
export const CreateInput = z.object({
  date: z.string().regex(DATE_RE),
  time: z.enum(SLOT_TIMES),
  dressId: z.string().min(1),
  dressSize: z.string().min(1),
  shoeId: z.string().min(1).nullable(),
  shoeSize: z.number().int().nullable(),
  payMethod: z.enum(PAY_METHODS),
  agree: z.literal(true),
});
export type CreateInput = z.infer<typeof CreateInput>;

const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function makeCode(day: string) {
  let s = '';
  for (let i = 0; i < 6; i++) s += CODE_CHARS[randomInt(0, CODE_CHARS.length)];
  return `R${day.slice(5, 7)}${day.slice(8, 10)}-${s}`;
}

/** Postgres 오류 코드/제약조건 이름 꺼내기 (drizzle이 원래 오류를 cause에 감쌈) */
function pgError(e: unknown): { code?: string; constraint?: string } {
  const err = e as { code?: string; constraint?: string; cause?: { code?: string; constraint?: string } };
  return { code: err?.code ?? err?.cause?.code, constraint: err?.constraint ?? err?.cause?.constraint };
}

export async function createReservation(input: CreateInput, userId: string, locale: 'ko' | 'en') {
  await expirePending();

  const { first, last } = bookableRange();
  if (input.date < first || input.date > last) throw new BookingError('INVALID');
  if (!enabledPayMethods()[input.payMethod]) throw new BookingError('METHOD');
  if ((input.shoeId === null) !== (input.shoeSize === null)) throw new BookingError('INVALID');

  const [closed] = await db.select().from(closedDays).where(eq(closedDays.day, input.date));
  if (closed) throw new BookingError('CLOSED');

  const dress = await db.query.dresses.findFirst({ where: and(eq(dresses.id, input.dressId), eq(dresses.active, true)) });
  if (!dress || !dress.sizes.includes(input.dressSize)) throw new BookingError('INVALID');
  const shoe = input.shoeId
    ? await db.query.shoes.findFirst({ where: and(eq(shoes.id, input.shoeId), eq(shoes.active, true)) })
    : null;
  if (input.shoeId && !shoe) throw new BookingError('INVALID');

  // 금액은 항상 서버에서 계산
  const amountKrw = dress.priceKrw + (shoe?.priceKrw ?? 0);
  const fittingAt = kstDateTime(input.date, input.time);
  const lockDays: string[] = [];
  for (let i = -DRESS_BUFFER_DAYS; i <= DRESS_BUFFER_DAYS; i++) lockDays.push(addDays(input.date, i));
  const paymentAmount = input.payMethod === 'PAYPAL' ? usdFromKrw(amountKrw) : amountKrw.toFixed(2);

  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      return await db.transaction(
        async (tx) => {
          // 신발 재고: 같은 사이즈가 기간 안에 몇 켤레 나가 있는지 확인
          if (input.shoeId && input.shoeSize !== null) {
            const [stock] = await tx
              .select()
              .from(shoeStocks)
              .where(and(eq(shoeStocks.shoeId, input.shoeId), eq(shoeStocks.size, input.shoeSize)));
            if (!stock || stock.quantity <= 0) throw new BookingError('SHOE');
            const [{ n }] = await tx
              .select({ n: sql<number>`count(*)::int` })
              .from(reservations)
              .where(
                and(
                  eq(reservations.shoeId, input.shoeId),
                  eq(reservations.shoeSize, input.shoeSize),
                  inArray(reservations.status, [...ACTIVE]),
                  between(reservations.fittingDate, lockDays[0], lockDays[lockDays.length - 1]),
                ),
              );
            if (n >= stock.quantity) throw new BookingError('SHOE');
          }

          const [resv] = await tx
            .insert(reservations)
            .values({
              code: makeCode(input.date),
              userId,
              fittingAt,
              fittingDate: input.date,
              dressId: dress.id,
              dressSize: input.dressSize,
              shoeId: shoe?.id ?? null,
              shoeSize: input.shoeSize,
              payMethod: input.payMethod,
              amountKrw,
              dueAt: new Date(Date.now() + HOLD_HOURS * 3600 * 1000),
              locale,
            })
            .returning();

          // 잠금 INSERT: 이미 누가 잡았으면 여기서 DB가 거부함
          await tx.insert(slotLocks).values({ fittingAt, reservationId: resv.id });
          await tx.insert(dressDayLocks).values(lockDays.map((day) => ({ dressId: dress.id, day, reservationId: resv.id })));

          await tx.insert(payments).values({
            reservationId: resv.id,
            method: input.payMethod,
            amount: paymentAmount,
            currency: input.payMethod === 'PAYPAL' ? 'USD' : 'KRW',
          });
          return resv;
        },
        { isolationLevel: 'serializable' },
      );
    } catch (e) {
      if (e instanceof BookingError) throw e;
      const { code, constraint } = pgError(e);
      if (code === '23505') {
        if (constraint?.startsWith('slot_locks')) throw new BookingError('SLOT');
        if (constraint?.startsWith('dress_day_locks')) throw new BookingError('DRESS');
        if (constraint?.startsWith('reservations_code')) continue; // 예약번호 우연히 겹침 → 다시
      }
      if (code === '40001') continue; // 동시 요청 충돌 → 다시 시도
      throw e;
    }
  }
  throw new BookingError('SLOT');
}

// ── 상태 바꾸기 ──────────────────────────────────────────
/** 고객 취소는 결제 대기 상태만. 결제 후 취소는 관리자에게 문의. */
export async function cancelReservation(id: string, opts: { byAdmin: boolean; userId?: string }) {
  return db.transaction(async (tx) => {
    const [r] = await tx.select().from(reservations).where(eq(reservations.id, id)).for('update');
    if (!r || (!opts.byAdmin && r.userId !== opts.userId)) throw new BookingError('NOT_FOUND');
    const allowed = opts.byAdmin ? r.status === 'PENDING' || r.status === 'CONFIRMED' : r.status === 'PENDING';
    if (!allowed) throw new BookingError('STATE');
    await tx.update(reservations).set({ status: 'CANCELLED', cancelledAt: new Date() }).where(eq(reservations.id, id));
    await releaseLocks(tx, [id], 'VOID');
    // 이미 결제된 건은 환불 필요로 표시
    await tx
      .update(payments)
      .set({ status: 'REFUND_NEEDED' })
      .where(and(eq(payments.reservationId, id), eq(payments.status, 'PAID')));
  });
}

/** 결제 확인 → 예약 확정 (관리자 입금 확인, 또는 PayPal 자동) */
export async function confirmPaid(
  id: string,
  info: { payerName?: string | null; note?: string | null; externalId?: string | null; raw?: unknown },
) {
  return db.transaction(async (tx) => {
    const [r] = await tx.select().from(reservations).where(eq(reservations.id, id)).for('update');
    if (!r) throw new BookingError('NOT_FOUND');
    if (r.status === 'CONFIRMED') return r; // 이미 처리됨 (PayPal 중복 알림 등)
    if (r.status !== 'PENDING') throw new BookingError('STATE');
    const now = new Date();
    const [updated] = await tx
      .update(reservations)
      .set({ status: 'CONFIRMED', confirmedAt: now })
      .where(eq(reservations.id, id))
      .returning();
    await tx
      .update(payments)
      .set({
        status: 'PAID',
        paidAt: now,
        payerName: info.payerName ?? null,
        note: info.note ?? null,
        ...(info.externalId ? { externalId: info.externalId } : {}),
        ...(info.raw ? { raw: info.raw } : {}),
      })
      .where(and(eq(payments.reservationId, id), eq(payments.status, 'PENDING')));
    return updated;
  });
}

/** 대여 끝 → 완료 처리, 남은 잠금 해제 */
export async function completeReservation(id: string) {
  return db.transaction(async (tx) => {
    const [r] = await tx.select().from(reservations).where(eq(reservations.id, id)).for('update');
    if (!r || r.status !== 'CONFIRMED') throw new BookingError('STATE');
    await tx.update(reservations).set({ status: 'COMPLETED' }).where(eq(reservations.id, id));
    await tx.delete(slotLocks).where(eq(slotLocks.reservationId, id));
    await tx.delete(dressDayLocks).where(eq(dressDayLocks.reservationId, id));
  });
}
