import 'server-only';
import { cookies } from 'next/headers';
import { dictionaries, type Locale } from './i18n';

export async function getLocale(): Promise<Locale> {
  const jar = await cookies();
  return jar.get('lang')?.value === 'en' ? 'en' : 'ko';
}

export async function getDict() {
  const locale = await getLocale();
  return { locale, t: dictionaries[locale] };
}
