// 날짜는 전부 한국 시간(KST, UTC+9, 서머타임 없음) 기준으로 다룸.
const KST_MS = 9 * 60 * 60 * 1000;

export const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

/** 오늘 한국 날짜 'YYYY-MM-DD' */
export function kstToday(now = new Date()): string {
  return new Date(now.getTime() + KST_MS).toISOString().slice(0, 10);
}

export function addDays(day: string, n: number): string {
  const d = new Date(`${day}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

/** 한국 날짜 + 'HH:MM' → 실제 시각 */
export function kstDateTime(day: string, time: string): Date {
  return new Date(`${day}T${time}:00+09:00`);
}

/** 시각 → 한국 기준 'HH:MM' */
export function kstTime(d: Date): string {
  return new Date(d.getTime() + KST_MS).toISOString().slice(11, 16);
}

/** 요일 번호 (0=일) */
export function weekday(day: string): number {
  return new Date(`${day}T00:00:00Z`).getUTCDay();
}

/** 'MM.DD HH:mm' (한국 시간) */
export function fmtKst(d: Date): string {
  const s = new Date(d.getTime() + KST_MS).toISOString();
  return `${s.slice(5, 7)}.${s.slice(8, 10)} ${s.slice(11, 16)}`;
}

/** 'MM.DD' */
export function fmtDay(day: string): string {
  return `${day.slice(5, 7)}.${day.slice(8, 10)}`;
}
