import { paypal } from './config';

export const krw = (n: number) => `₩ ${n.toLocaleString('ko-KR')}`;

/** 원화 → 달러 (센트 단위 올림). PAYPAL_KRW_PER_USD 기준 */
export function usdFromKrw(amountKrw: number): string {
  if (!paypal.krwPerUsd) throw new Error('PAYPAL_KRW_PER_USD가 설정되지 않았습니다');
  return (Math.ceil((amountKrw / paypal.krwPerUsd) * 100) / 100).toFixed(2);
}
