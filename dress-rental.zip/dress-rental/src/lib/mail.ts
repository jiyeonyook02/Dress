import 'server-only';
import nodemailer from 'nodemailer';

/** SMTP가 설정돼 있으면 메일 발송, 아니면(개발 중) 터미널에 출력 */
export async function sendMail(to: string, subject: string, text: string) {
  if (!process.env.SMTP_HOST) {
    if (process.env.NODE_ENV === 'production') throw new Error('SMTP_HOST가 설정되지 않았습니다');
    console.log(`\n[메일 미발송: SMTP 없음] to=${to}\n${subject}\n${text}\n`);
    return;
  }
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT ?? 587),
    secure: Number(process.env.SMTP_PORT) === 465,
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
  });
  await transporter.sendMail({ from: process.env.MAIL_FROM, to, subject, text });
}
