import 'server-only';
import { paypal, SITE_URL } from './config';

// PAYPAL_MODE=api 일 때만 사용. PayPal Orders API v2.
const base = () => (paypal.env === 'live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com');

async function accessToken() {
  const res = await fetch(`${base()}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${Buffer.from(`${paypal.clientId}:${paypal.clientSecret}`).toString('base64')}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  });
  if (!res.ok) throw new Error(`PayPal token ${res.status}`);
  return ((await res.json()) as { access_token: string }).access_token;
}

type Link = { href: string; rel: string };

/** 주문 생성 → 고객이 결제할 PayPal 주소 반환 */
export async function createPaypalOrder(opts: { reservationCode: string; amountUsd: string; locale: 'ko' | 'en' }) {
  const token = await accessToken();
  const res = await fetch(`${base()}/v2/checkout/orders`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      'PayPal-Request-Id': `create-${opts.reservationCode}-${Date.now()}`,
    },
    body: JSON.stringify({
      intent: 'CAPTURE',
      purchase_units: [
        {
          reference_id: opts.reservationCode,
          custom_id: opts.reservationCode,
          description: `Dress fitting reservation ${opts.reservationCode}`,
          amount: { currency_code: 'USD', value: opts.amountUsd },
        },
      ],
      payment_source: {
        paypal: {
          experience_context: {
            user_action: 'PAY_NOW',
            shipping_preference: 'NO_SHIPPING',
            locale: opts.locale === 'en' ? 'en-US' : 'ko-KR',
            return_url: `${SITE_URL}/api/paypal/return`,
            cancel_url: `${SITE_URL}/book/done/${opts.reservationCode}?paypal=cancelled`,
          },
        },
      },
    }),
  });
  const data = (await res.json()) as { id?: string; links?: Link[] };
  if (!res.ok || !data.id) throw new Error(`PayPal create ${res.status}: ${JSON.stringify(data)}`);
  const approve = data.links?.find((l) => l.rel === 'payer-action' || l.rel === 'approve');
  if (!approve) throw new Error('PayPal approve link missing');
  return { orderId: data.id, approveUrl: approve.href };
}

export type CaptureResult = {
  status: string;
  reservationCode: string | null;
  value: string | null;
  currency: string | null;
  raw: unknown;
};

/** 고객이 결제 승인 후 돌아오면 실제 결제(캡처) */
export async function capturePaypalOrder(orderId: string): Promise<CaptureResult> {
  const token = await accessToken();
  const res = await fetch(`${base()}/v2/checkout/orders/${encodeURIComponent(orderId)}/capture`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      'PayPal-Request-Id': `capture-${orderId}`,
    },
  });
  const data = (await res.json()) as {
    status?: string;
    purchase_units?: { payments?: { captures?: { status: string; custom_id?: string; amount: { value: string; currency_code: string } }[] } }[];
  };
  if (!res.ok) throw new Error(`PayPal capture ${res.status}: ${JSON.stringify(data)}`);
  const cap = data.purchase_units?.[0]?.payments?.captures?.[0];
  return {
    status: cap?.status ?? data.status ?? 'UNKNOWN',
    reservationCode: cap?.custom_id ?? null,
    value: cap?.amount.value ?? null,
    currency: cap?.amount.currency_code ?? null,
    raw: data,
  };
}

/** link 모드: paypal.me 주소 */
export function paypalMeUrl(amountUsd: string) {
  return `https://paypal.me/${encodeURIComponent(paypal.meHandle)}/${amountUsd}USD`;
}
