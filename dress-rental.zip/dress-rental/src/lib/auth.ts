import 'server-only';
import { createHmac, randomInt, timingSafeEqual } from 'crypto';
import { and, desc, eq, gt, isNull } from 'drizzle-orm';
import { db, schema } from '@/db';
import { sendMail } from './mail';
import { kakao, SITE_URL } from './config';

const CODE_TTL_MIN = 10;
const RESEND_COOLDOWN_SEC = 60;
const MAX_ATTEMPTS = 5;

function hashCode(email: string, code: string) {
  return createHmac('sha256', process.env.AUTH_SECRET ?? '')
    .update(`${email}:${code}`)
    .digest('hex');
}

export class AuthError extends Error {
  constructor(public code: 'COOLDOWN' | 'INVALID' | 'EXPIRED' | 'TOO_MANY' | 'KAKAO') {
    super(code);
  }
}

export async function sendEmailCode(rawEmail: string, locale: 'ko' | 'en') {
  const email = rawEmail.trim().toLowerCase();
  const last = await db.query.emailCodes.findFirst({
    where: eq(schema.emailCodes.email, email),
    orderBy: desc(schema.emailCodes.createdAt),
  });
  if (last && Date.now() - last.createdAt.getTime() < RESEND_COOLDOWN_SEC * 1000) throw new AuthError('COOLDOWN');

  const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
  const [row] = await db
    .insert(schema.emailCodes)
    .values({
      email,
      codeHash: hashCode(email, code),
      expiresAt: new Date(Date.now() + CODE_TTL_MIN * 60 * 1000),
    })
    .returning({ id: schema.emailCodes.id });
  const subject = locale === 'en' ? 'Your sign-in code' : '로그인 인증번호';
  const text =
    locale === 'en'
      ? `Your code is ${code}. It expires in ${CODE_TTL_MIN} minutes.`
      : `인증번호는 ${code} 입니다. ${CODE_TTL_MIN}분 안에 입력해 주세요.`;
  try {
    await sendMail(email, subject, text);
  } catch (e) {
    // 메일이 안 나갔으면 기록도 지워서 1분 대기에 걸리지 않게
    await db.delete(schema.emailCodes).where(eq(schema.emailCodes.id, row.id));
    throw e;
  }
}

/** 인증번호 확인 → 회원 찾기/만들기 → user id 반환 */
export async function verifyEmailCode(rawEmail: string, code: string): Promise<string> {
  const email = rawEmail.trim().toLowerCase();
  const row = await db.query.emailCodes.findFirst({
    where: and(eq(schema.emailCodes.email, email), isNull(schema.emailCodes.usedAt), gt(schema.emailCodes.expiresAt, new Date())),
    orderBy: desc(schema.emailCodes.createdAt),
  });
  if (!row) throw new AuthError('EXPIRED');
  if (row.attempts >= MAX_ATTEMPTS) throw new AuthError('TOO_MANY');

  const a = Buffer.from(row.codeHash, 'hex');
  const b = Buffer.from(hashCode(email, code), 'hex');
  if (a.length !== b.length || !timingSafeEqual(a, b)) {
    await db
      .update(schema.emailCodes)
      .set({ attempts: row.attempts + 1 })
      .where(eq(schema.emailCodes.id, row.id));
    throw new AuthError('INVALID');
  }
  await db.update(schema.emailCodes).set({ usedAt: new Date() }).where(eq(schema.emailCodes.id, row.id));

  const [user] = await db
    .insert(schema.users)
    .values({ email, provider: 'EMAIL', name: email.split('@')[0] })
    .onConflictDoUpdate({ target: schema.users.email, set: { email } })
    .returning();
  return user.id;
}

// ── 카카오 로그인 ────────────────────────────────────────
export const KAKAO_REDIRECT = `${SITE_URL}/api/auth/kakao/callback`;

export function kakaoAuthorizeUrl(state: string) {
  const u = new URL('https://kauth.kakao.com/oauth/authorize');
  u.searchParams.set('client_id', kakao.restApiKey);
  u.searchParams.set('redirect_uri', KAKAO_REDIRECT);
  u.searchParams.set('response_type', 'code');
  u.searchParams.set('state', state);
  return u.toString();
}

export async function kakaoLogin(code: string): Promise<string> {
  const body = new URLSearchParams({
    grant_type: 'authorization_code',
    client_id: kakao.restApiKey,
    redirect_uri: KAKAO_REDIRECT,
    code,
  });
  if (kakao.clientSecret) body.set('client_secret', kakao.clientSecret);
  const tokenRes = await fetch('https://kauth.kakao.com/oauth/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8' },
    body,
  });
  if (!tokenRes.ok) throw new AuthError('KAKAO');
  const token = (await tokenRes.json()) as { access_token?: string };
  if (!token.access_token) throw new AuthError('KAKAO');

  const meRes = await fetch('https://kapi.kakao.com/v2/user/me', {
    headers: { Authorization: `Bearer ${token.access_token}` },
  });
  if (!meRes.ok) throw new AuthError('KAKAO');
  const me = (await meRes.json()) as {
    id: number;
    kakao_account?: { email?: string; is_email_verified?: boolean; profile?: { nickname?: string } };
  };
  const kakaoId = String(me.id);
  const name = me.kakao_account?.profile?.nickname ?? null;
  // 이메일은 카카오 앱 설정(동의항목)에서 받도록 했고, 인증된 경우에만 저장
  const email =
    me.kakao_account?.email && me.kakao_account.is_email_verified ? me.kakao_account.email.toLowerCase() : null;

  const existing = await db.query.users.findFirst({ where: eq(schema.users.kakaoId, kakaoId) });
  if (existing) {
    await db.update(schema.users).set({ name: name ?? existing.name }).where(eq(schema.users.id, existing.id));
    return existing.id;
  }
  // 같은 이메일로 이미 가입한 회원이 있으면 계정 연결
  if (email) {
    const byEmail = await db.query.users.findFirst({ where: eq(schema.users.email, email) });
    if (byEmail) {
      await db.update(schema.users).set({ kakaoId }).where(eq(schema.users.id, byEmail.id));
      return byEmail.id;
    }
  }
  const [user] = await db.insert(schema.users).values({ kakaoId, email, name, provider: 'KAKAO' }).returning();
  return user.id;
}
