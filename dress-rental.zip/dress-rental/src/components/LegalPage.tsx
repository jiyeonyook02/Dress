import { getDict } from '@/lib/locale';

/** 약관류 페이지 틀. 실제 내용은 src/app/terms, privacy, refund 의 page.tsx 문단을 바꿔 넣으면 됨. */
export async function LegalPage({ titleKey, bodyKo, bodyEn }: { titleKey: 'terms' | 'privacy' | 'refundPolicy'; bodyKo: string[]; bodyEn: string[] }) {
  const { locale, t } = await getDict();
  const body = locale === 'en' ? bodyEn : bodyKo;
  return (
    <main className="page">
      <article className="narrow" style={{ maxWidth: 720 }}>
        <h1 style={{ fontSize: 34 }}>{t[titleKey]}</h1>
        {body.map((p, i) => (
          <p key={i} className="sub" style={{ margin: 0, lineHeight: 2 }}>{p}</p>
        ))}
      </article>
    </main>
  );
}
