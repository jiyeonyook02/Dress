'use client';
import { useState } from 'react';

export function CancelButton({ code, label, confirmText }: { code: string; label: string; confirmText: string }) {
  const [busy, setBusy] = useState(false);
  return (
    <button
      type="button"
      className="btn-ghost"
      disabled={busy}
      onClick={async () => {
        if (!window.confirm(confirmText)) return;
        setBusy(true);
        await fetch(`/api/reservations/${encodeURIComponent(code)}/cancel`, { method: 'POST' });
        window.location.reload();
      }}
    >
      {label}
    </button>
  );
}
