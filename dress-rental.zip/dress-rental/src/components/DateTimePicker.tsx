'use client';
import { useEffect, useState } from 'react';
import type { Dictionary } from '@/lib/i18n';

export type DaySummary = { date: string; left: number; closed: boolean };
export type Slot = { time: string; available: boolean };

const dow = (date: string, t: Dictionary) => t.dow[new Date(`${date}T00:00:00Z`).getUTCDay()];
const mmdd = (date: string) => `${date.slice(5, 7)}.${date.slice(8, 10)}`;

/** 날짜 + 시간 고르기 (홈 예약창과 예약 1단계에서 같이 씀) */
export function DateTimePicker({
  t,
  days,
  date,
  time,
  onChange,
  slots: outerSlots,
}: {
  t: Dictionary;
  days: DaySummary[];
  date: string | null;
  time: string | null;
  onChange: (date: string, time: string | null) => void;
  /** 부모가 이미 빈자리를 불러왔으면 넘겨줌 (그럼 여기서 다시 안 불러옴) */
  slots?: Slot[] | null;
}) {
  const [ownSlots, setSlots] = useState<Slot[] | null>(null);
  const [loading, setLoading] = useState(false);
  const external = outerSlots !== undefined;
  const slots = external ? outerSlots : ownSlots;

  useEffect(() => {
    if (!date || external) return;
    let alive = true;
    setLoading(true);
    fetch(`/api/availability?date=${date}`, { cache: 'no-store' })
      .then((r) => r.json())
      .then((data) => {
        if (!alive) return;
        setSlots(data.detail?.slots ?? []);
        // 고른 시간이 그새 마감됐으면 해제
        if (time && !data.detail?.slots?.find((s: Slot) => s.time === time && s.available)) onChange(date, null);
      })
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date]);

  return (
    <div className="stack" style={{ gap: 28 }}>
      <div className="stack-s">
        <span className="label">DATE</span>
        <div className="grid-days">
          {days.map((d) => {
            const unavailable = d.closed || d.left === 0;
            return (
              <button
                key={d.date}
                type="button"
                className={`pill${unavailable ? ' dim' : ''}`}
                aria-pressed={date === d.date}
                onClick={() => onChange(d.date, null)}
              >
                {mmdd(d.date)}
                <small>
                  {dow(d.date, t)} · {d.closed ? t.closed : d.left ? t.leftN.replace('{n}', String(d.left)) : t.full}
                </small>
              </button>
            );
          })}
        </div>
      </div>
      <div className="stack-s">
        <span className="label">{t.timeLabel}</span>
        <div className="grid-times" aria-busy={loading}>
          {(slots ?? []).map((s) => (
            <button
              key={s.time}
              type="button"
              className="pill"
              disabled={!s.available}
              aria-pressed={time === s.time}
              onClick={() => date && onChange(date, s.time)}
            >
              {s.time}
              <small>{s.available ? t.avail : t.booked}</small>
            </button>
          ))}
          {!date && <p className="muted" style={{ margin: 0 }}>{t.pickDT}</p>}
        </div>
      </div>
    </div>
  );
}

export { dow, mmdd };
