'use client';
import { useState } from 'react';
import type { Dictionary } from '@/lib/i18n';
import { DateTimePicker, dow, mmdd, type DaySummary } from './DateTimePicker';

export function HomeBooking({ t, days, loggedIn }: { t: Dictionary; days: DaySummary[]; loggedIn: boolean }) {
  const [date, setDate] = useState<string | null>(null);
  const [time, setTime] = useState<string | null>(null);

  const go = () => {
    if (!date || !time) return;
    const target = `/book?date=${date}&time=${encodeURIComponent(time)}`;
    // 로그인 안 했으면 로그인 → 다시 예약으로
    window.location.href = loggedIn ? target : `/login?gate=1&next=${encodeURIComponent(target)}`;
  };

  return (
    <div style={{ borderTop: '1px solid var(--ink)', paddingTop: 28 }} className="stack">
      <DateTimePicker
        t={t}
        days={days}
        date={date}
        time={time}
        onChange={(d, tm) => {
          setDate(d);
          setTime(tm);
        }}
      />
      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: 16, borderTop: '1px solid var(--line)', paddingTop: 24 }}>
        <span className="sub">
          {date && time ? t.fitting.replace('{when}', `${mmdd(date)} (${dow(date, t)}) ${time}`) : t.pickDT}
        </span>
        <button type="button" className="cta" disabled={!time} onClick={go}>
          {!time ? t.ctaPick : loggedIn ? t.ctaNext : t.ctaLogin}
        </button>
      </div>
    </div>
  );
}
