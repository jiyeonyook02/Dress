'use client';
import { useState } from 'react';
import type { Dictionary, Locale } from '@/lib/i18n';

const ERR: Record<string, keyof Dictionary> = {
  EMAIL: 'errEmail',
  INVALID: 'errCode',
  EXPIRED: 'errExpired',
  TOO_MANY: 'errTooMany',
  COOLDOWN: 'errCooldown',
};

export function LoginForm({ t, locale, next, kakaoEnabled }: { t: Dictionary; locale: Locale; next: string; kakaoEnabled: boolean }) {
  const [step, setStep] = useState<'email' | 'code'>('email');
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const errText = (key?: string) => String(t[ERR[key ?? ''] ?? 'errGeneric']);

  async function send(resend = false) {
    setBusy(true);
    setMsg(null);
    const res = await fetch('/api/auth/email/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, locale }),
    });
    setBusy(false);
    if (!res.ok) return setMsg(errText((await res.json().catch(() => ({}))).error));
    setStep('code');
    if (resend) setMsg(t.resent);
  }

  async function verify() {
    setBusy(true);
    setMsg(null);
    const res = await fetch('/api/auth/email/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, code }),
    });
    if (!res.ok) {
      setBusy(false);
      return setMsg(errText((await res.json().catch(() => ({}))).error));
    }
    window.location.href = next;
  }

  if (step === 'code') {
    return (
      <form
        className="narrow"
        style={{ maxWidth: 'none' }}
        onSubmit={(e) => {
          e.preventDefault();
          verify();
        }}
      >
        <div className="center stack-s">
          <span className="caps muted">Verification</span>
          <p className="sub" style={{ margin: 0 }}>{t.verifyMsg.replace('{email}', email)}</p>
        </div>
        <label className="field">
          CODE
          <input
            inputMode="numeric"
            autoComplete="one-time-code"
            maxLength={6}
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
            placeholder="000000"
            style={{ fontSize: 28, letterSpacing: '0.5em', textAlign: 'center' }}
            autoFocus
          />
        </label>
        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <button type="button" className="linkbtn" onClick={() => send(true)} disabled={busy}>
            {t.resend}
          </button>
        </div>
        {msg && <p className="err" role="alert">{msg}</p>}
        <button type="submit" className="cta" disabled={busy || code.length !== 6}>
          {t.verifyBtn}
        </button>
        <button type="button" className="navbtn muted" style={{ justifyContent: 'center' }} onClick={() => setStep('email')}>
          {t.reenter}
        </button>
      </form>
    );
  }

  return (
    <form
      className="narrow"
      style={{ maxWidth: 'none' }}
      onSubmit={(e) => {
        e.preventDefault();
        send();
      }}
    >
      {kakaoEnabled && (
        <>
          <a className="kakao" href={`/api/auth/kakao?next=${encodeURIComponent(next)}`}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
              <path d="M12 3C6.5 3 2 6.5 2 10.8c0 2.8 1.9 5.2 4.7 6.6l-1 3.6 4.1-2.7c.7.1 1.4.2 2.2.2 5.5 0 10-3.5 10-7.7S17.5 3 12 3z" />
            </svg>
            {t.kakao}
          </a>
          <div className="or">OR</div>
        </>
      )}
      <label className="field">
        EMAIL
        <input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@example.com" />
      </label>
      {msg && <p className="err" role="alert">{msg}</p>}
      <button type="submit" className="cta" disabled={busy || !email}>
        {t.sendCode}
      </button>
      <p className="muted center" style={{ margin: 0, fontSize: 13 }}>{t.loginHint}</p>
    </form>
  );
}
