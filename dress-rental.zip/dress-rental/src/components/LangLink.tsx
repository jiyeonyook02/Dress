'use client';
import { usePathname, useSearchParams } from 'next/navigation';
import { Suspense } from 'react';

function Inner({ to, className, children }: { to: 'ko' | 'en'; className?: string; children: React.ReactNode }) {
  const path = usePathname();
  const qs = useSearchParams().toString();
  const next = qs ? `${path}?${qs}` : path;
  return (
    <a href={`/api/lang?to=${to}&next=${encodeURIComponent(next)}`} className={className} lang={to}>
      {children}
    </a>
  );
}

export function LangLink(props: { to: 'ko' | 'en'; className?: string; children: React.ReactNode }) {
  return (
    <Suspense fallback={<a href={`/api/lang?to=${props.to}`} className={props.className}>{props.children}</a>}>
      <Inner {...props} />
    </Suspense>
  );
}
