'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import type { Dictionary, Locale } from '@/lib/i18n';
import { sizeLabel } from '@/lib/i18n';
import { DateTimePicker, dow, mmdd, type DaySummary, type Slot } from './DateTimePicker';

type DressAvail = {
  id: string;
  code: string;
  nameKo: string;
  nameEn: string;
  type: 'MERMAID' | 'ALINE' | 'BALLGOWN' | 'MINI';
  sizes: string[];
  priceKrw: number;
  imageUrl: string | null;
  available: boolean;
};
type ShoeAvail = {
  id: string;
  nameKo: string;
  nameEn: string;
  heelCm: number;
  priceKrw: number;
  imageUrl: string | null;
  sizes: { size: number; left: number }[];
};
type Detail = { date: string; closed: boolean; slots: Slot[]; dresses: DressAvail[]; shoes: ShoeAvail[] };
type Methods = { BANK: boolean; STORE: boolean; PAYPAL: boolean };
type Method = keyof Methods;

const SIZE_ROWS = [
  ['44', '80', '61', '86'],
  ['55', '84', '64', '90'],
  ['66', '88', '68', '94'],
  ['77', '92', '72', '98'],
];
const ALL_SIZES = ['44', '55', '66', '77'];
const krw = (n: number) => `₩ ${n.toLocaleString('ko-KR')}`;

export function BookingFlow(props: {
  t: Dictionary;
  locale: Locale;
  days: DaySummary[];
  initialDate: string | null;
  initialTime: string | null;
  methods: Methods;
  holdHours: number;
  krwPerUsd: number;
}) {
  const { t, locale, methods } = props;
  const [step, setStep] = useState(props.initialDate && props.initialTime ? 2 : 1);
  const [date, setDate] = useState<string | null>(props.initialDate);
  const [time, setTime] = useState<string | null>(props.initialTime);
  const [detail, setDetail] = useState<Detail | null>(null);
  const [dressId, setDressId] = useState<string | null>(null);
  const [size, setSize] = useState<string | null>(null);
  const [shoeId, setShoeId] = useState<string | null>(null); // 'none' = 선택 안 함
  const [shoeSize, setShoeSize] = useState<number | null>(null);
  const [guide, setGuide] = useState(false);
  const [region, setRegion] = useState<'kr' | 'intl'>(locale === 'en' ? 'intl' : 'kr');
  const [method, setMethod] = useState<Method | null>(null);
  const [agree, setAgree] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async (d: string) => {
    const res = await fetch(`/api/availability?date=${d}`, { cache: 'no-store' });
    const data = await res.json();
    setDetail(data.detail);
    return data.detail as Detail;
  }, []);

  useEffect(() => {
    if (date) load(date);
  }, [date, load]);

  // 날짜가 바뀌어 고른 드레스/시간이 불가해지면 해제
  useEffect(() => {
    if (!detail) return;
    if (time && !detail.slots.find((s) => s.time === time)?.available) setTime(null);
    if (dressId && !detail.dresses.find((d) => d.id === dressId)?.available) setDressId(null);
  }, [detail]); // eslint-disable-line react-hooks/exhaustive-deps

  const dress = detail?.dresses.find((d) => d.id === dressId) ?? null;
  const shoe = shoeId && shoeId !== 'none' ? (detail?.shoes.find((s) => s.id === shoeId) ?? null) : null;
  const amount = (dress?.priceKrw ?? 0) + (shoe?.priceKrw ?? 0);
  const regionMethods = useMemo<Method[]>(
    () => (region === 'kr' ? (['BANK', 'STORE'] as Method[]) : (['PAYPAL'] as Method[])).filter((m) => methods[m]),
    [region, methods],
  );
  useEffect(() => {
    setMethod((m) => (m && regionMethods.includes(m) ? m : (regionMethods[0] ?? null)));
  }, [regionMethods]);

  const ok =
    step === 1
      ? !!date && !!time
      : step === 2
        ? !!dress && !!size
        : step === 3
          ? shoeId === 'none' || (!!shoe && shoeSize !== null)
          : !!method && agree;

  const when = date && time ? `${mmdd(date)} (${dow(date, t)}) ${time}` : '-';
  const name = (x: { nameKo: string; nameEn: string }) => (locale === 'en' ? x.nameEn : x.nameKo);

  async function submit() {
    if (!ok || busy || !date || !time || !dress || !size || !method) return;
    setBusy(true);
    setErr(null);
    const res = await fetch('/api/reservations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        date,
        time,
        dressId: dress.id,
        dressSize: size,
        shoeId: shoe ? shoe.id : null,
        shoeSize: shoe ? shoeSize : null,
        payMethod: method,
        agree: true,
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (res.ok) {
      window.location.href = `/book/done/${data.code}`;
      return;
    }
    setBusy(false);
    if (res.status === 401) {
      window.location.href = `/login?gate=1&next=${encodeURIComponent(`/book?date=${date}&time=${time}`)}`;
      return;
    }
    await load(date);
    if (data.error === 'SLOT') {
      setTime(null);
      setStep(1);
      setErr(t.errSlot);
    } else if (data.error === 'DRESS') {
      setDressId(null);
      setStep(2);
      setErr(t.errDress);
    } else if (data.error === 'SHOE') {
      setShoeSize(null);
      setStep(3);
      setErr(t.errShoe);
    } else setErr(t.errInvalid);
  }

  const next = () => {
    if (!ok) return;
    setErr(null);
    if (step === 4) submit();
    else setStep(step + 1);
  };
  const back = () => {
    setErr(null);
    if (step === 1) window.location.href = '/';
    else setStep(step - 1);
  };

  return (
    <div className="stack" style={{ gap: 48 }}>
      <ol className="steps" aria-label="steps">
        {t.steps.map((label, i) => (
          <li key={label} className={i + 1 === step ? 'cur' : i + 1 < step ? 'done' : ''} aria-current={i + 1 === step ? 'step' : undefined}>
            <span>0{i + 1}</span>
            {label}
          </li>
        ))}
      </ol>

      {step === 1 && (
        <section className="stack">
          <h1 className="title-l">{t.s1Title}</h1>
          <DateTimePicker
            t={t}
            days={props.days}
            date={date}
            time={time}
            slots={date ? (detail?.date === date ? detail.slots : null) : null}
            onChange={(d, tm) => {
              setDate(d);
              setTime(tm);
            }}
          />
        </section>
      )}

      {step === 2 && detail && (
        <section className="stack">
          <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'baseline', gap: 12 }}>
            <h1 className="title-l">{t.s2Title}</h1>
            <span className="muted" style={{ fontSize: 14 }}>{t.s2Note}</span>
          </div>
          <div className="choose">
            {detail.dresses.map((d) => (
              <button
                key={d.id}
                type="button"
                className="choice"
                disabled={!d.available}
                aria-pressed={dressId === d.id}
                onClick={() => {
                  setDressId(d.id);
                  if (size && !d.sizes.includes(size)) setSize(null);
                }}
              >
                <div className="ph">{d.imageUrl ? <img src={d.imageUrl} alt="" /> : d.available ? 'IMAGE' : 'RESERVED'}</div>
                <span className="meta">
                  <span>{name(d)}</span>
                  <span className="muted" style={{ fontSize: 14 }}>{krw(d.priceKrw)}</span>
                </span>
                <span className="muted" style={{ fontSize: 13, marginTop: -4 }}>{d.available ? t.types[d.type] : t.reserved}</span>
              </button>
            ))}
          </div>
          <div className="stack-s" style={{ borderTop: '1px solid var(--ink)', paddingTop: 24, gap: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <span className="label">SIZE</span>
              <button type="button" className="linkbtn" aria-expanded={guide} onClick={() => setGuide(!guide)}>
                {t.guide} {guide ? '−' : '+'}
              </button>
            </div>
            <div className="grid-sizes">
              {ALL_SIZES.map((z) => {
                const has = !dress || dress.sizes.includes(z);
                return (
                  <button key={z} type="button" className="pill" disabled={!dress || !has} aria-pressed={size === z} onClick={() => setSize(z)}>
                    {sizeLabel(z, locale)}
                    {dress && !has && <small>{t.noSize}</small>}
                  </button>
                );
              })}
            </div>
            {guide && (
              <div className="table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>{t.thSize}</th>
                      <th>{t.thBust}</th>
                      <th>{t.thWaist}</th>
                      <th>{t.thHip}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {SIZE_ROWS.map((r) => (
                      <tr key={r[0]}>
                        <td>{sizeLabel(r[0], locale)}</td>
                        <td>{r[1]}</td>
                        <td>{r[2]}</td>
                        <td>{r[3]}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <p className="muted" style={{ margin: '14px 0 0', fontSize: 13, lineHeight: 1.8 }}>{t.guideNote}</p>
              </div>
            )}
          </div>
        </section>
      )}

      {step === 3 && detail && (
        <section className="stack">
          <h1 className="title-l">{t.s3Title}</h1>
          <div className="choose">
            {detail.shoes.map((s) => (
              <button
                key={s.id}
                type="button"
                className="choice square"
                aria-pressed={shoeId === s.id}
                onClick={() => {
                  setShoeId(s.id);
                  setShoeSize(null);
                }}
              >
                <div className="ph">{s.imageUrl ? <img src={s.imageUrl} alt="" /> : 'IMAGE'}</div>
                <span className="meta">
                  <span>{name(s)}</span>
                  <span className="muted" style={{ fontSize: 14 }}>{krw(s.priceKrw)}</span>
                </span>
                <span className="muted" style={{ fontSize: 13, marginTop: -4 }}>{t.heel.replace('{n}', String(s.heelCm))}</span>
              </button>
            ))}
            <button
              type="button"
              className="choice square"
              aria-pressed={shoeId === 'none'}
              onClick={() => {
                setShoeId('none');
                setShoeSize(null);
              }}
            >
              <div className="ph" style={{ background: '#fff', border: '1px dashed var(--line-2)' }}>—</div>
              <span className="meta">{t.noShoes}</span>
              <span className="muted" style={{ fontSize: 13, marginTop: -4 }}>{t.bringOwn}</span>
            </button>
          </div>
          {shoe && (
            <div className="stack-s" style={{ borderTop: '1px solid var(--ink)', paddingTop: 24, gap: 16 }}>
              <span className="label">{t.shoeSizeLabel}</span>
              <div className="grid-sizes">
                {shoe.sizes.map((z) => (
                  <button key={z.size} type="button" className="pill" disabled={z.left === 0} aria-pressed={shoeSize === z.size} onClick={() => setShoeSize(z.size)}>
                    {z.size}
                    {z.left === 0 && <small>{t.soldOut}</small>}
                  </button>
                ))}
              </div>
            </div>
          )}
        </section>
      )}

      {step === 4 && (
        <section className="split">
          <div className="stack" style={{ gap: 28 }}>
            <h1 className="title-l">{t.s4Title}</h1>
            <div className="seg">
              <button type="button" aria-pressed={region === 'kr'} onClick={() => setRegion('kr')}>
                {t.regionKr}
              </button>
              <button type="button" aria-pressed={region === 'intl'} onClick={() => setRegion('intl')}>
                {t.regionIntl}
              </button>
            </div>
            <div className="stack-s" style={{ gap: 10 }}>
              <span className="label">PAYMENT METHOD</span>
              {regionMethods.length === 0 && <p className="note">{t.noMethod}</p>}
              {regionMethods.map((m) => (
                <button key={m} type="button" className="method" aria-pressed={method === m} onClick={() => setMethod(m)}>
                  <span className="top">
                    <span>{t[m]}</span>
                    <span className="dot" />
                  </span>
                  <p>{t[`${m}Desc`].replace('{h}', String(props.holdHours))}</p>
                </button>
              ))}
            </div>
            <label className="check">
              <input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
              <span>{t.agree}</span>
            </label>
            <p className="muted" style={{ margin: 0, fontSize: 13, lineHeight: 1.9 }}>{t.refund}</p>
          </div>
          <div className="box">
            <span className="label">ORDER SUMMARY</span>
            <div className="kv"><span>{t.kWhen}</span><span>{when}</span></div>
            <div className="kv"><span>{t.kDress}</span><span>{dress ? `${name(dress)} · ${sizeLabel(size ?? '', locale)}` : '-'}</span></div>
            <div className="kv"><span>{t.kShoes}</span><span>{shoe ? `${name(shoe)} · ${shoeSize}mm` : t.noShoes}</span></div>
            <div className="kv"><span>{t.kPay}</span><span>{method ? t[method] : '-'}</span></div>
            <div className="kv total">
              <span style={{ color: 'var(--ink)' }}>{t.total}</span>
              <span>
                {krw(amount)}
                {method === 'PAYPAL' && props.krwPerUsd > 0 && (
                  <small className="muted" style={{ display: 'block', fontSize: 13 }}>
                    ≈ USD {(Math.ceil((amount / props.krwPerUsd) * 100) / 100).toFixed(2)}
                  </small>
                )}
              </span>
            </div>
          </div>
        </section>
      )}

      {err && <p className="err" role="alert">{err}</p>}

      <div className="nav-row">
        <button type="button" className="navbtn muted" onClick={back}>
          {t.back}
        </button>
        <button type="button" className="cta" disabled={!ok || busy} onClick={next}>
          {step === 4 ? t.reserve : t.next}
        </button>
      </div>
    </div>
  );
}
