'use client';
import { useEffect, useState } from 'react';
import type { Dictionary, Locale } from '@/lib/i18n';
import { LangLink } from './LangLink';

type Props = {
  t: Dictionary;
  locale: Locale;
  loggedIn: boolean;
  isAdmin: boolean;
  shoes: { id: string; name: string; heelCm: number }[];
  contact: { manager: string; phone: string; phoneHref: string; kakao: string; hours: string };
};

const TYPES = ['MERMAID', 'ALINE', 'BALLGOWN', 'MINI'] as const;

export function SideMenu({ t, locale, loggedIn, isAdmin, shoes, contact }: Props) {
  const [open, setOpen] = useState(false);
  const [dressOpen, setDressOpen] = useState(false);
  const [shoeOpen, setShoeOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <button type="button" className="iconbtn" aria-label={t.openMenu} aria-expanded={open} onClick={() => setOpen(true)}>
        <svg width="26" height="14" viewBox="0 0 26 14" fill="none" stroke="currentColor" strokeWidth="1.2" aria-hidden="true">
          <path d="M0 1h26M0 7h26M0 13h18" />
        </svg>
      </button>
      <span className="caps">Menu</span>

      {open && (
        <div className="side-wrap">
          <aside className="side" aria-label="menu">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 32 }}>
              <span className="caps">Menu</span>
              <button type="button" className="iconbtn" style={{ justifyContent: 'flex-end' }} aria-label={t.closeMenu} onClick={() => setOpen(false)}>
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.2" aria-hidden="true">
                  <path d="M1 1l16 16M17 1L1 17" />
                </svg>
              </button>
            </div>

            <a href="/book" className="side-item">
              {t.sideBook}
              <span className="caps muted">Book</span>
            </a>

            <button type="button" className="side-item" aria-expanded={dressOpen} onClick={() => setDressOpen(!dressOpen)}>
              {t.sideDresses}
              <span className="muted">{dressOpen ? '−' : '+'}</span>
            </button>
            {dressOpen && (
              <div className="side-sub">
                {TYPES.map((k) => (
                  <a key={k} href={`/?type=${k}#new`} onClick={() => setOpen(false)}>
                    {t.types[k]}
                    {locale === 'ko' && <span className="muted" style={{ fontStyle: 'italic' }}>{k === 'ALINE' ? 'A-line' : k.charAt(0) + k.slice(1).toLowerCase()}</span>}
                  </a>
                ))}
              </div>
            )}

            <button type="button" className="side-item" aria-expanded={shoeOpen} onClick={() => setShoeOpen(!shoeOpen)}>
              {t.sideShoes}
              <span className="muted">{shoeOpen ? '−' : '+'}</span>
            </button>
            {shoeOpen && (
              <div className="side-sub">
                {shoes.map((s) => (
                  <span key={s.id} className="row">
                    {s.name}
                    <span className="muted" style={{ fontSize: 13 }}>{t.heel.replace('{n}', String(s.heelCm))}</span>
                  </span>
                ))}
              </div>
            )}

            <div style={{ borderBottom: '1px solid var(--line)', padding: '20px 0 24px', display: 'flex', flexDirection: 'column', gap: 14 }}>
              <span style={{ fontSize: 22 }}>{t.sideContact}</span>
              <dl className="dl">
                <dt>{t.cManager}</dt>
                <dd>{contact.manager}</dd>
                <dt>{t.cPhone}</dt>
                <dd>
                  <a href={contact.phoneHref} style={{ borderBottom: '1px solid var(--ink)' }}>
                    {contact.phone}
                  </a>
                </dd>
                <dt>{t.cKakao}</dt>
                <dd>{contact.kakao}</dd>
                <dt>{t.cHours}</dt>
                <dd>{contact.hours}</dd>
              </dl>
            </div>

            <div style={{ marginTop: 'auto', paddingTop: 32, display: 'flex', flexWrap: 'wrap', gap: '8px 24px' }}>
              {loggedIn ? (
                <>
                  <a href="/my" className="navbtn">MY PAGE</a>
                  {isAdmin && <a href="/admin" className="navbtn">ADMIN</a>}
                  <form action="/api/auth/logout" method="post">
                    <button type="submit" className="navbtn muted">LOGOUT</button>
                  </form>
                </>
              ) : (
                <a href="/login" className="navbtn">LOGIN</a>
              )}
              <LangLink to={locale === 'ko' ? 'en' : 'ko'} className="navbtn muted">
                {t.langLong}
              </LangLink>
            </div>
          </aside>
          <button type="button" className="side-dim" aria-label={t.closeMenu} onClick={() => setOpen(false)} />
        </div>
      )}
    </div>
  );
}
