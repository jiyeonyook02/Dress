import type { Metadata } from 'next';
import './globals.css';
import { getDict } from '@/lib/locale';
import { getUser } from '@/lib/session';
import { db, schema } from '@/db';
import { asc, eq } from 'drizzle-orm';
import { SideMenu } from '@/components/SideMenu';
import { LangLink } from '@/components/LangLink';
import { site } from '@/content/site';

export const metadata: Metadata = {
  title: site.brand,
  description: 'Dress rental & private fitting',
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const { locale, t } = await getDict();
  const user = await getUser();
  const shoeList = await db.select().from(schema.shoes).where(eq(schema.shoes.active, true)).orderBy(asc(schema.shoes.sortOrder));

  return (
    <html lang={locale}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;1,400&family=Noto+Serif+KR:wght@300;400;500&family=Noto+Sans+KR:wght@400;500&display=swap"
        />
      </head>
      <body>
        <div className="topbar">{t.topbar}</div>
        <header className="header">
          <div className="header-grid">
            <SideMenu
              t={t}
              locale={locale}
              loggedIn={!!user}
              isAdmin={!!user?.isAdmin}
              shoes={shoeList.map((s) => ({ id: s.id, name: locale === 'en' ? s.nameEn : s.nameKo, heelCm: s.heelCm }))}
              contact={{
                manager: locale === 'en' ? site.managerEn : site.managerKo,
                phone: site.phone,
                phoneHref: site.phoneHref,
                kakao: site.kakaoChannel,
                hours: locale === 'en' ? site.hoursEn : site.hoursKo,
              }}
            />
            <a href="/" className="brand">
              {site.brand}
            </a>
            <div className="header-right">
              <a href="/book" className="navbtn hide-sm">
                BOOK
              </a>
              {user ? (
                <a href="/my" className="navbtn">
                  MY PAGE
                </a>
              ) : (
                <a href="/login" className="navbtn">
                  LOGIN
                </a>
              )}
              <LangLink to={locale === 'ko' ? 'en' : 'ko'} className="langbtn">
                {t.langSwitch}
              </LangLink>
            </div>
          </div>
        </header>
        {children}
        <footer className="site">
          <div>
            {t.footer}
            <br />
            <a href="/terms">{t.terms}</a> · <a href="/privacy">{t.privacy}</a> · <a href="/refund">{t.refundPolicy}</a>
          </div>
          <span style={{ fontSize: 22, letterSpacing: '0.42em', color: '#111' }}>{site.brand}</span>
        </footer>
      </body>
    </html>
  );
}
