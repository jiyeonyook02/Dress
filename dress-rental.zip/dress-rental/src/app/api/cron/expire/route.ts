import { expirePending } from '@/lib/booking';
import { fail, json } from '@/lib/http';

export const dynamic = 'force-dynamic';

// 결제 기한 지난 예약 자동 취소. vercel.json 의 cron 이 주기적으로 호출.
// (사이트 접속 때마다도 한 번씩 실행되므로 cron이 없어도 크게 문제 없음)
export async function GET(req: Request) {
  const secret = process.env.CRON_SECRET;
  if (!secret || req.headers.get('authorization') !== `Bearer ${secret}`) return fail('UNAUTHORIZED', 401);
  const expired = await expirePending();
  return json({ expired });
}
