import { NextResponse } from 'next/server';
import { and, eq } from 'drizzle-orm';
import { db, schema } from '@/db';
import { getUser } from '@/lib/session';
import { getLocale } from '@/lib/locale';
import { createPaypalOrder } from '@/lib/paypal';
import { paypal, SITE_URL } from '@/lib/config';

// api 모드: 예약 → PayPal 결제창으로 이동
export async function GET(req: Request) {
  const code = new URL(req.url).searchParams.get('code') ?? '';
  const done = `${SITE_URL}/book/done/${encodeURIComponent(code)}`;
  const user = await getUser();
  if (!user) return NextResponse.redirect(`${SITE_URL}/login?next=${encodeURIComponent(`/book/done/${code}`)}`);
  if (paypal.mode !== 'api') return NextResponse.redirect(done);

  const resv = await db.query.reservations.findFirst({ where: eq(schema.reservations.code, code) });
  if (!resv || resv.userId !== user.id || resv.status !== 'PENDING' || resv.payMethod !== 'PAYPAL' || resv.dueAt < new Date()) {
    return NextResponse.redirect(done);
  }
  const payment = await db.query.payments.findFirst({
    where: and(eq(schema.payments.reservationId, resv.id), eq(schema.payments.status, 'PENDING')),
  });
  if (!payment) return NextResponse.redirect(done);

  try {
    const { orderId, approveUrl } = await createPaypalOrder({
      reservationCode: resv.code,
      amountUsd: payment.amount,
      locale: await getLocale(),
    });
    // 주문번호 저장 → 돌아왔을 때 어느 예약인지 확인용
    await db.update(schema.payments).set({ externalId: orderId }).where(eq(schema.payments.id, payment.id));
    return NextResponse.redirect(approveUrl);
  } catch (e) {
    console.error(e);
    return NextResponse.redirect(`${done}?paypal=failed`);
  }
}
