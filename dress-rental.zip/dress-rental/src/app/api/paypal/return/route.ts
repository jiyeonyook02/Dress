import { NextResponse } from 'next/server';
import { eq } from 'drizzle-orm';
import { db, schema } from '@/db';
import { capturePaypalOrder } from '@/lib/paypal';
import { BookingError, confirmPaid } from '@/lib/booking';
import { SITE_URL } from '@/lib/config';
import { notifyReservation } from '@/lib/notify';

// 고객이 PayPal에서 결제 승인 후 돌아오는 곳 (?token=주문번호)
export async function GET(req: Request) {
  const orderId = new URL(req.url).searchParams.get('token');
  if (!orderId) return NextResponse.redirect(`${SITE_URL}/my`);

  const payment = await db.query.payments.findFirst({
    where: eq(schema.payments.externalId, orderId),
    with: { reservation: true },
  });
  if (!payment) return NextResponse.redirect(`${SITE_URL}/my`);
  const resv = payment.reservation;
  const done = `${SITE_URL}/book/done/${resv.code}`;
  if (payment.status === 'PAID') return NextResponse.redirect(`${done}?paypal=paid`);

  try {
    const cap = await capturePaypalOrder(orderId);
    // 금액·통화·예약번호가 우리가 만든 주문과 같은지 확인
    const ok =
      cap.status === 'COMPLETED' &&
      cap.reservationCode === resv.code &&
      cap.currency === 'USD' &&
      Number(cap.value) === Number(payment.amount);
    if (!ok) {
      await db.update(schema.payments).set({ raw: cap.raw, note: 'PayPal 확인 불일치 — 확인 필요' }).where(eq(schema.payments.id, payment.id));
      return NextResponse.redirect(`${done}?paypal=failed`);
    }
    try {
      await confirmPaid(resv.id, { externalId: orderId, raw: cap.raw, note: 'PayPal 자동 확인' });
    } catch (e) {
      // 기한이 지나 이미 만료된 예약에 돈이 들어온 경우 → 환불 필요로 기록
      if (e instanceof BookingError && e.code === 'STATE') {
        await db
          .update(schema.payments)
          .set({ status: 'REFUND_NEEDED', paidAt: new Date(), raw: cap.raw, note: '만료 후 결제됨 — 환불 필요' })
          .where(eq(schema.payments.id, payment.id));
        return NextResponse.redirect(`${done}?paypal=failed`);
      }
      throw e;
    }
    await notifyReservation(resv.id, 'confirmed');
    return NextResponse.redirect(`${done}?paypal=paid`);
  } catch (e) {
    console.error(e);
    return NextResponse.redirect(`${done}?paypal=failed`);
  }
}
