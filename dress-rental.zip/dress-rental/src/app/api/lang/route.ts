import { NextResponse } from 'next/server';
import { safeNext } from '@/lib/http';
import { SITE_URL } from '@/lib/config';

// /api/lang?to=en&next=/book  → 언어 쿠키 설정 후 원래 페이지로
export async function GET(req: Request) {
  const url = new URL(req.url);
  const to = url.searchParams.get('to') === 'en' ? 'en' : 'ko';
  const res = NextResponse.redirect(`${SITE_URL}${safeNext(url.searchParams.get('next'))}`);
  res.cookies.set('lang', to, { path: '/', maxAge: 60 * 60 * 24 * 365, sameSite: 'lax' });
  return res;
}
