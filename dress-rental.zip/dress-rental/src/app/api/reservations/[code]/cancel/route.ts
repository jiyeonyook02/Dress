import { eq } from 'drizzle-orm';
import { db, schema } from '@/db';
import { BookingError, cancelReservation } from '@/lib/booking';
import { getUser } from '@/lib/session';
import { fail, json } from '@/lib/http';

// 고객 본인 취소 (결제 대기 상태만 가능)
export async function POST(_req: Request, ctx: { params: Promise<{ code: string }> }) {
  const user = await getUser();
  if (!user) return fail('LOGIN', 401);
  const { code } = await ctx.params;
  const resv = await db.query.reservations.findFirst({ where: eq(schema.reservations.code, code) });
  if (!resv || resv.userId !== user.id) return fail('NOT_FOUND', 404);
  try {
    await cancelReservation(resv.id, { byAdmin: false, userId: user.id });
    return json({ ok: true });
  } catch (e) {
    if (e instanceof BookingError) return fail(e.code);
    console.error(e);
    return fail('GENERIC', 500);
  }
}
