import { BookingError, CreateInput, createReservation } from '@/lib/booking';
import { getUser } from '@/lib/session';
import { getLocale } from '@/lib/locale';
import { fail, json } from '@/lib/http';
import { notifyReservation } from '@/lib/notify';

export async function POST(req: Request) {
  const user = await getUser();
  if (!user) return fail('LOGIN', 401); // 로그인 안 하면 예약 불가

  const parsed = CreateInput.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return fail('INVALID');

  try {
    const resv = await createReservation(parsed.data, user.id, await getLocale());
    await notifyReservation(resv.id, 'created');
    return json({ code: resv.code }, 201);
  } catch (e) {
    if (e instanceof BookingError) return fail(e.code, e.code === 'SLOT' || e.code === 'DRESS' || e.code === 'SHOE' ? 409 : 400);
    console.error(e);
    return fail('GENERIC', 500);
  }
}
