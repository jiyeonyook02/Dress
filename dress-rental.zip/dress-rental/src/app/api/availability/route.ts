import { expirePending, getAvailability, getDaysSummary, BookingError } from '@/lib/booking';
import { fail, json } from '@/lib/http';

export const dynamic = 'force-dynamic';

// GET /api/availability            → 날짜별 남은 시간대 수
// GET /api/availability?date=YYYY-MM-DD → 그 날 시간대·드레스·신발 가능 여부
export async function GET(req: Request) {
  const date = new URL(req.url).searchParams.get('date');
  try {
    await expirePending();
    const days = await getDaysSummary();
    const detail = date ? await getAvailability(date) : null;
    return json({ days, detail });
  } catch (e) {
    if (e instanceof BookingError) return fail(e.code);
    console.error(e);
    return fail('GENERIC', 500);
  }
}
