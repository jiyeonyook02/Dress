import { z } from 'zod';
import { AuthError, sendEmailCode } from '@/lib/auth';
import { fail, json } from '@/lib/http';

const Body = z.object({ email: z.string().email().max(254), locale: z.enum(['ko', 'en']).default('ko') });

export async function POST(req: Request) {
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return fail('EMAIL');
  try {
    await sendEmailCode(parsed.data.email, parsed.data.locale);
    return json({ ok: true });
  } catch (e) {
    if (e instanceof AuthError) return fail(e.code, 429);
    console.error(e);
    return fail('GENERIC', 500);
  }
}
