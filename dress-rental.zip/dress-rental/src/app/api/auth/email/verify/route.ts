import { z } from 'zod';
import { AuthError, verifyEmailCode } from '@/lib/auth';
import { createSession } from '@/lib/session';
import { fail, json } from '@/lib/http';

const Body = z.object({ email: z.string().email().max(254), code: z.string().regex(/^\d{6}$/) });

export async function POST(req: Request) {
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return fail('INVALID');
  try {
    const userId = await verifyEmailCode(parsed.data.email, parsed.data.code);
    await createSession(userId);
    return json({ ok: true });
  } catch (e) {
    if (e instanceof AuthError) return fail(e.code, 400);
    console.error(e);
    return fail('GENERIC', 500);
  }
}
