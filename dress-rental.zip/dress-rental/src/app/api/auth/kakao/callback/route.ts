import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { kakaoLogin } from '@/lib/auth';
import { createSession } from '@/lib/session';
import { safeNext } from '@/lib/http';
import { SITE_URL } from '@/lib/config';

export async function GET(req: Request) {
  const url = new URL(req.url);
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const jar = await cookies();
  const saved = jar.get('kakao_state')?.value;
  jar.delete('kakao_state');

  let next = '/';
  try {
    const parsed = saved ? (JSON.parse(saved) as { state: string; next: string }) : null;
    if (!parsed || !code || parsed.state !== state) throw new Error('state');
    next = safeNext(parsed.next);
    const userId = await kakaoLogin(code);
    await createSession(userId);
    return NextResponse.redirect(`${SITE_URL}${next}`);
  } catch (e) {
    console.error('kakao login failed', e);
    return NextResponse.redirect(`${SITE_URL}/login?error=KAKAO&next=${encodeURIComponent(next)}`);
  }
}
