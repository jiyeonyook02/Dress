import { randomBytes } from 'crypto';
import { NextResponse } from 'next/server';
import { kakaoAuthorizeUrl } from '@/lib/auth';
import { safeNext } from '@/lib/http';

// 카카오 로그인 시작 → 카카오 동의 화면으로 이동
export async function GET(req: Request) {
  const next = safeNext(new URL(req.url).searchParams.get('next'));
  const state = randomBytes(16).toString('hex');
  const res = NextResponse.redirect(kakaoAuthorizeUrl(state));
  res.cookies.set('kakao_state', JSON.stringify({ state, next }), {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 600,
  });
  return res;
}
