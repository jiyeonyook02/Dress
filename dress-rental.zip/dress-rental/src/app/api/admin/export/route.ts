import { desc } from 'drizzle-orm';
import { db, schema } from '@/db';
import { getUser } from '@/lib/session';
import { fail } from '@/lib/http';
import { fmtKst, kstTime } from '@/lib/dates';

export const dynamic = 'force-dynamic';

// 예약 전체를 CSV(엑셀에서 열림)로 내려받기
export async function GET() {
  const user = await getUser();
  if (!user?.isAdmin) return fail('FORBIDDEN', 403);
  const rows = await db.query.reservations.findMany({
    orderBy: desc(schema.reservations.fittingAt),
    with: { user: true, dress: true, shoe: true, payments: true },
  });
  const head = ['예약번호', '피팅날짜', '시간', '상태', '고객', '이메일', '드레스', '사이즈', '신발', '신발사이즈', '결제수단', '금액(원)', '결제금액', '통화', '결제상태', '입금자명', '접수', '메모'];
  const esc = (v: unknown) => {
    const s = v === null || v === undefined ? '' : String(v);
    // 엑셀 수식 주입 방지
    const safe = /^[=+\-@]/.test(s) ? `'${s}` : s;
    return `"${safe.replace(/"/g, '""')}"`;
  };
  const lines = rows.map((r) => {
    const p = r.payments[0];
    return [
      r.code,
      r.fittingDate,
      kstTime(r.fittingAt),
      r.status,
      r.user.name,
      r.user.email,
      r.dress.code,
      r.dressSize,
      r.shoe?.nameKo ?? '',
      r.shoeSize ?? '',
      r.payMethod,
      r.amountKrw,
      p?.amount ?? '',
      p?.currency ?? '',
      p?.status ?? '',
      p?.payerName ?? '',
      fmtKst(r.createdAt),
      r.adminMemo ?? '',
    ]
      .map(esc)
      .join(',');
  });
  // 앞의 BOM은 엑셀에서 한글 안 깨지게
  const csv = '﻿' + [head.map(esc).join(','), ...lines].join('\r\n');
  return new Response(csv, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="reservations-${new Date().toISOString().slice(0, 10)}.csv"`,
    },
  });
}
