import { notFound, redirect } from 'next/navigation';
import { eq } from 'drizzle-orm';
import { db, schema } from '@/db';
import { getUser } from '@/lib/session';
import { getDict } from '@/lib/locale';
import { bank, paypal, SMARTSTORE_URL } from '@/lib/config';
import { fmtDay, fmtKst, kstTime } from '@/lib/dates';
import { paypalMeUrl } from '@/lib/paypal';
import { krw } from '@/lib/money';
import { fill, sizeLabel } from '@/lib/i18n';

export const dynamic = 'force-dynamic';

export default async function DonePage({
  params,
  searchParams,
}: {
  params: Promise<{ code: string }>;
  searchParams: Promise<{ paypal?: string }>;
}) {
  const { code } = await params;
  const sp = await searchParams;
  const user = await getUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(`/book/done/${code}`)}`);
  const r = await db.query.reservations.findFirst({
    where: eq(schema.reservations.code, code),
    with: { dress: true, shoe: true, payments: true },
  });
  if (!r || (r.userId !== user.id && !user.isAdmin)) notFound();

  const { locale, t } = await getDict();
  const pay = r.payments[0];
  const paid = r.status === 'CONFIRMED' || r.status === 'COMPLETED';
  const pending = r.status === 'PENDING';
  const due = fmtKst(r.dueAt);
  const vars = { code: r.code, due };
  const amountText = r.payMethod === 'PAYPAL' && pay ? `USD ${pay.amount}` : krw(r.amountKrw);

  const payLink =
    r.payMethod === 'STORE'
      ? SMARTSTORE_URL
      : r.payMethod === 'PAYPAL'
        ? paypal.mode === 'api'
          ? `/api/paypal/start?code=${encodeURIComponent(r.code)}`
          : pay
            ? paypalMeUrl(pay.amount)
            : ''
        : '';

  return (
    <main className="page">
      <section className="narrow center" style={{ maxWidth: 600 }}>
        <span className="caps muted">{paid ? 'Confirmed' : pending ? 'Awaiting payment' : t[`st_${r.status}`].replace(' · {due}', '')}</span>
        <h1 style={{ fontSize: 36 }}>{paid ? t.doneTitlePaid : t.doneTitle}</h1>
        {sp.paypal === 'cancelled' && pending && <p className="note">{t.paypalCancelled}</p>}
        {sp.paypal === 'failed' && <p className="err">{t.paypalFailed}</p>}

        {pending && (
          <>
            <p className="sub" style={{ margin: 0, lineHeight: 1.9 }}>{fill(t.doneLead, vars)}</p>
            <div className="box strong" style={{ textAlign: 'left' }}>
              <span className="label">{r.payMethod === 'BANK' ? t.boxBank : r.payMethod === 'STORE' ? t.boxStore : t.boxPaypal}</span>
              {r.payMethod === 'BANK' ? (
                <>
                  <div className="kv"><span>{t.bBank}</span><span>{bank.name}</span></div>
                  <div className="kv"><span>{t.bAcct}</span><span>{bank.account}</span></div>
                  <div className="kv"><span>{t.bHolder}</span><span>{bank.holder}</span></div>
                  <div className="kv"><span>{t.kAmount}</span><span>{amountText}</span></div>
                  <div className="kv"><span>{t.bDue}</span><span>{due}</span></div>
                </>
              ) : (
                <>
                  <div className="kv"><span>{t.kAmount}</span><span>{amountText}</span></div>
                  {payLink && (
                    <a className="cta" href={payLink} target={payLink.startsWith('http') ? '_blank' : undefined} rel="noopener noreferrer">
                      {r.payMethod === 'STORE' ? t.linkStore : t.linkPaypal}
                    </a>
                  )}
                </>
              )}
              <p style={{ margin: '4px 0 0', paddingTop: 14, borderTop: '1px solid var(--line)', fontSize: 14, lineHeight: 1.8 }}>
                {r.payMethod === 'BANK'
                  ? fill(t.memoBank, vars)
                  : r.payMethod === 'STORE'
                    ? fill(t.memoStore, vars)
                    : paypal.mode === 'api'
                      ? t.memoPaypalApi
                      : fill(t.memoPaypal, vars)}
              </p>
            </div>
          </>
        )}

        <div className="box" style={{ textAlign: 'left', border: 0, borderTop: '1px solid var(--line)', padding: '16px 0 0' }}>
          <div className="kv"><span>{t.kWhen}</span><span>{`${fmtDay(r.fittingDate)} ${kstTime(r.fittingAt)}`}</span></div>
          <div className="kv">
            <span>{t.kDress}</span>
            <span>{`${locale === 'en' ? r.dress.nameEn : r.dress.nameKo} · ${sizeLabel(r.dressSize, locale)}`}</span>
          </div>
          <div className="kv">
            <span>{t.kShoes}</span>
            <span>{r.shoe ? `${locale === 'en' ? r.shoe.nameEn : r.shoe.nameKo} · ${r.shoeSize}mm` : t.noShoes}</span>
          </div>
          <div className="kv"><span>{t.kPay}</span><span>{`${t[r.payMethod]} · ${amountText}`}</span></div>
        </div>
        {pending && <p className="muted" style={{ margin: 0, fontSize: 13, lineHeight: 1.9 }}>{t.doneFoot}</p>}
        <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 8 }}>
          <a className="cta" href="/my">{t.toMy}</a>
          <a className="btn-line" href="/">{t.toHome}</a>
        </div>
      </section>
    </main>
  );
}
