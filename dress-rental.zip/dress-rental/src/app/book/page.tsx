import { redirect } from 'next/navigation';
import { getDict } from '@/lib/locale';
import { getUser } from '@/lib/session';
import { expirePending, getDaysSummary } from '@/lib/booking';
import { enabledPayMethods, HOLD_HOURS, paypal, SLOT_TIMES } from '@/lib/config';
import { DATE_RE } from '@/lib/dates';
import { BookingFlow } from '@/components/BookingFlow';

export const dynamic = 'force-dynamic';

export default async function BookPage({ searchParams }: { searchParams: Promise<{ date?: string; time?: string }> }) {
  const sp = await searchParams;
  const date = sp.date && DATE_RE.test(sp.date) ? sp.date : null;
  const time = sp.time && (SLOT_TIMES as readonly string[]).includes(sp.time) ? sp.time : null;

  const user = await getUser();
  if (!user) {
    const back = date && time ? `/book?date=${date}&time=${encodeURIComponent(time)}` : '/book';
    redirect(`/login?gate=1&next=${encodeURIComponent(back)}`);
  }
  const { locale, t } = await getDict();
  await expirePending();
  const days = await getDaysSummary();

  return (
    <main className="page">
      <div className="wrap">
        <BookingFlow
          t={t}
          locale={locale}
          days={days}
          initialDate={date && days.some((d) => d.date === date) ? date : null}
          initialTime={time}
          methods={enabledPayMethods()}
          holdHours={HOLD_HOURS}
          krwPerUsd={paypal.krwPerUsd}
        />
      </div>
    </main>
  );
}
