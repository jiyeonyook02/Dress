import { LegalPage } from '@/components/LegalPage';

export default function Terms() {
  return <LegalPage titleKey="terms" bodyKo={['[이용약관 내용을 넣어 주세요]']} bodyEn={['[Terms of service]']} />;
}
