import { redirect } from 'next/navigation';
import { desc, eq } from 'drizzle-orm';
import { db, schema } from '@/db';
import { getUser } from '@/lib/session';
import { getDict } from '@/lib/locale';
import { expirePending } from '@/lib/booking';
import { fmtDay, fmtKst, kstTime } from '@/lib/dates';
import { fill, sizeLabel } from '@/lib/i18n';
import { krw } from '@/lib/money';
import { CancelButton } from '@/components/CancelButton';
import { site } from '@/content/site';

export const dynamic = 'force-dynamic';

export default async function MyPage() {
  const user = await getUser();
  if (!user) redirect('/login?next=/my');
  await expirePending();
  const { locale, t } = await getDict();
  const list = await db.query.reservations.findMany({
    where: eq(schema.reservations.userId, user.id),
    orderBy: desc(schema.reservations.fittingAt),
    with: { dress: true, shoe: true, payments: true },
  });

  return (
    <main className="page">
      <div className="wrap stack" style={{ gap: 48, maxWidth: 880 }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'flex-end', gap: 16 }}>
          <div className="stack-s">
            <span className="caps muted">My page</span>
            <h1 style={{ fontSize: 36 }}>{fill(t.hello, { name: user.name ?? user.email ?? '' })}</h1>
            <span className="muted" style={{ fontSize: 14 }}>{t[`via${user.provider}`]}</span>
          </div>
          <form action="/api/auth/logout" method="post">
            <button type="submit" className="navbtn muted">LOGOUT</button>
          </form>
        </div>

        <section className="stack-s" style={{ gap: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <h2 className="caps">My reservations</h2>
            <span className="muted" style={{ fontSize: 14 }}>{fill(t.count, { n: list.length })}</span>
          </div>
          <div style={{ borderTop: '1px solid var(--ink)' }}>
            {list.length === 0 && (
              <div className="center stack-s" style={{ padding: '56px 0', alignItems: 'center', gap: 20, borderBottom: '1px solid var(--line)' }}>
                <span className="muted">{t.noResv}</span>
                <a className="cta" href="/book">{t.sideBook}</a>
              </div>
            )}
            {list.map((r) => {
              const pay = r.payments[0];
              const amount = r.payMethod === 'PAYPAL' && pay ? `USD ${pay.amount}` : krw(r.amountKrw);
              return (
                <article key={r.id} className="resv">
                  <div className="stack-s" style={{ gap: 8 }}>
                    <span className="label">{r.code}</span>
                    <span className={`badge ${r.status}`}>{fill(t[`st_${r.status}`], { due: fmtKst(r.dueAt) })}</span>
                    <span style={{ fontSize: 24 }}>{`${fmtDay(r.fittingDate)} ${kstTime(r.fittingAt)}`}</span>
                    <span className="muted" style={{ fontSize: 14 }}>{locale === 'en' ? site.addressEn : site.addressKo}</span>
                  </div>
                  <dl className="dl" style={{ gridTemplateColumns: '72px 1fr' }}>
                    <dt>{t.kDress}</dt>
                    <dd>{`${locale === 'en' ? r.dress.nameEn : r.dress.nameKo} · ${sizeLabel(r.dressSize, locale)}`}</dd>
                    <dt>{t.kShoes}</dt>
                    <dd>{r.shoe ? `${locale === 'en' ? r.shoe.nameEn : r.shoe.nameKo} · ${r.shoeSize}mm` : t.noShoes}</dd>
                    <dt>{t.kPay}</dt>
                    <dd>{`${t[r.payMethod]} · ${amount}`}</dd>
                  </dl>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'flex-start' }}>
                    {r.status === 'PENDING' && (
                      <>
                        <a className="btn-line" href={`/book/done/${r.code}`}>{t.payNow}</a>
                        <CancelButton code={r.code} label={t.cancelBtn} confirmText={t.cancelConfirm} />
                      </>
                    )}
                    {(r.status === 'CONFIRMED' || r.status === 'PENDING') && (
                      <a className="btn-ghost" href={site.phoneHref} style={{ display: 'inline-flex', alignItems: 'center' }}>{t.contactBtn}</a>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      </div>
    </main>
  );
}
