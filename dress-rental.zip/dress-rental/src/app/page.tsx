import { asc, eq } from 'drizzle-orm';
import { db, schema } from '@/db';
import { getDict } from '@/lib/locale';
import { getUser } from '@/lib/session';
import { expirePending, getDaysSummary } from '@/lib/booking';
import { HomeBooking } from '@/components/HomeBooking';
import { krw } from '@/lib/money';
import { site } from '@/content/site';
import type { DressType } from '@/db/schema';

export const dynamic = 'force-dynamic';

const TYPES: DressType[] = ['MERMAID', 'ALINE', 'BALLGOWN', 'MINI'];

export default async function Home({ searchParams }: { searchParams: Promise<{ type?: string }> }) {
  const { type } = await searchParams;
  const filter = TYPES.includes(type as DressType) ? (type as DressType) : null;
  const { locale, t } = await getDict();
  const user = await getUser();
  await expirePending();
  const [days, dressList] = await Promise.all([
    getDaysSummary(),
    db.select().from(schema.dresses).where(eq(schema.dresses.active, true)).orderBy(asc(schema.dresses.sortOrder)),
  ]);
  const shown = filter ? dressList.filter((d) => d.type === filter) : dressList;

  return (
    <main>
      <section className="hero">
        {site.heroImages.map((src, i) => (
          <div key={i} className="ph" style={{ background: i ? 'var(--ph-2)' : 'var(--ph)' }}>
            {src ? <img src={src} alt="" /> : `IMAGE · 0${i + 1}`}
          </div>
        ))}
      </section>

      <section id="reserve" style={{ padding: '120px 24px 0' }}>
        <div className="wrap stack" style={{ gap: 40 }}>
          <div className="center stack-s" style={{ gap: 14 }}>
            <span className="caps muted">Reservation</span>
            <h2 className="title-xl">Book your fitting</h2>
            <p className="sub" style={{ margin: 0 }}>{t.resvSub}</p>
          </div>
          <HomeBooking t={t} days={days} loggedIn={!!user} />
        </div>
      </section>

      <section id="new" className="sec">
        <div className="sec-head">
          <h2 className="caps">New in</h2>
          <span className="caps muted">{filter ? t.types[filter] : 'All'}</span>
        </div>
        <div className="products">
          {shown.map((d) => (
            <div key={d.id} className="product">
              <div className="ph">{d.imageUrl ? <img src={d.imageUrl} alt={locale === 'en' ? d.nameEn : d.nameKo} /> : 'IMAGE'}</div>
              <div className="product-meta">
                <span>{locale === 'en' ? d.nameEn : d.nameKo}</span>
                <span className="muted">{krw(d.priceKrw)}</span>
              </div>
              <span className="muted" style={{ fontSize: 13, padding: '0 2px' }}>{t.types[d.type]}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="sec">
        <h2 className="caps" style={{ marginBottom: 28 }}>Shop by occasion</h2>
        <div style={{ borderTop: '1px solid var(--ink)' }}>
          {['Small Wedding', 'Reception', 'Photo Shoot', 'Evening'].map((en, i) => (
            <div key={en} className="occ-row">
              <span className="big">{en}</span>
              <span className="muted" style={{ fontSize: 14 }}>{t.occ[i]}</span>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
