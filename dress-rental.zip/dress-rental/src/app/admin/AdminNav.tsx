'use client';
import { usePathname } from 'next/navigation';

const LINKS = [
  ['/admin', '예약 관리'],
  ['/admin/dresses', '드레스'],
  ['/admin/shoes', '신발'],
  ['/admin/closed', '휴무일'],
] as const;

export function AdminNav() {
  const path = usePathname();
  return (
    <nav className="admin-nav" aria-label="관리자 메뉴">
      <strong style={{ letterSpacing: '0.16em' }}>ADMIN</strong>
      {LINKS.map(([href, label]) => (
        <a key={href} href={href} aria-current={path === href ? 'page' : undefined}>
          {label}
        </a>
      ))}
      <a href="/api/admin/export" style={{ marginLeft: 'auto' }}>
        예약 CSV 내려받기
      </a>
    </nav>
  );
}
