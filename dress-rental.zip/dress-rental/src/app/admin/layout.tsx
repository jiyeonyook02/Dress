import { redirect } from 'next/navigation';
import { getUser } from '@/lib/session';
import { AdminNav } from './AdminNav';

export const dynamic = 'force-dynamic';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await getUser();
  // ADMIN_EMAILS 에 있는 이메일로 로그인한 사람만
  if (!user?.isAdmin) redirect('/login?next=/admin');
  return (
    <div className="admin">
      <AdminNav />
      {children}
    </div>
  );
}
