import { asc } from 'drizzle-orm';
import { db, schema } from '@/db';
import { saveShoeAction } from '../actions';

type ShoeWithStock = typeof schema.shoes.$inferSelect & { stocks: (typeof schema.shoeStocks.$inferSelect)[] };

function ShoeRow({ s }: { s?: ShoeWithStock }) {
  const stockText = s?.stocks
    .sort((a, b) => a.size - b.size)
    .map((x) => `${x.size}:${x.quantity}`)
    .join(', ');
  return (
    <form action={saveShoeAction} className="inline" style={{ padding: '10px 0', borderBottom: '1px solid var(--line)', width: '100%' }}>
      {s && <input type="hidden" name="id" value={s.id} />}
      <input type="hidden" name="back" value="/admin/shoes" />
      <input name="nameKo" defaultValue={s?.nameKo} placeholder="이름(한글)" required style={{ width: 120 }} aria-label="이름 한글" />
      <input name="nameEn" defaultValue={s?.nameEn} placeholder="Name (EN)" required style={{ width: 120 }} aria-label="이름 영문" />
      <input name="heelCm" type="number" min={0} defaultValue={s?.heelCm ?? 0} style={{ width: 60 }} aria-label="굽 cm" />
      <input name="priceKrw" type="number" min={0} step={1000} defaultValue={s?.priceKrw} placeholder="대여가(원)" required style={{ width: 100 }} aria-label="대여가" />
      <input
        name="stocks"
        defaultValue={stockText ?? '220:1, 225:1, 230:1, 235:1, 240:1, 245:1, 250:1'}
        style={{ width: 300 }}
        aria-label="사이즈:수량"
        title="사이즈:수량 을 쉼표로"
      />
      <input name="imageUrl" defaultValue={s?.imageUrl ?? ''} placeholder="이미지 주소" style={{ width: 140 }} aria-label="이미지" />
      <input name="sortOrder" type="number" defaultValue={s?.sortOrder ?? 0} style={{ width: 60 }} aria-label="순서" />
      <label style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}>
        <input type="checkbox" name="active" defaultChecked={s ? s.active : true} /> 노출
      </label>
      <button type="submit" className={s ? '' : 'primary'}>{s ? '저장' : '추가'}</button>
    </form>
  );
}

export default async function AdminShoes({ searchParams }: { searchParams: Promise<{ msg?: string }> }) {
  const { msg } = await searchParams;
  const list = await db.query.shoes.findMany({ orderBy: asc(schema.shoes.sortOrder), with: { stocks: true } });
  return (
    <div>
      <h1 style={{ fontSize: 28, marginBottom: 8 }}>신발</h1>
      <p className="muted" style={{ marginTop: 0 }}>
        재고는 &lsquo;사이즈:수량&rsquo;을 쉼표로 적어요. 예) 230:2, 235:1 — 같은 기간에 이 수량을 넘게 예약되지 않아요.
      </p>
      {msg && <p className="note">{msg}</p>}
      <div className="card">
        <strong>새 신발</strong>
        <ShoeRow />
      </div>
      <div className="card">
        {list.map((s) => (
          <ShoeRow key={s.id} s={s} />
        ))}
      </div>
    </div>
  );
}
