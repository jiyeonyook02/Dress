import { asc } from 'drizzle-orm';
import { db, schema } from '@/db';
import type { Dress } from '@/db/schema';
import { saveDressAction } from '../actions';

const TYPES = [
  ['MERMAID', '머메이드'],
  ['ALINE', 'A라인'],
  ['BALLGOWN', '볼가운'],
  ['MINI', '미니 · 미디'],
] as const;

function DressRow({ d }: { d?: Dress }) {
  return (
    <form action={saveDressAction} className="inline" style={{ padding: '10px 0', borderBottom: '1px solid var(--line)', width: '100%' }}>
      {d && <input type="hidden" name="id" value={d.id} />}
      <input type="hidden" name="back" value="/admin/dresses" />
      <input name="code" defaultValue={d?.code} placeholder="번호 No. 07" required style={{ width: 90 }} aria-label="번호" />
      <input name="nameKo" defaultValue={d?.nameKo} placeholder="이름(한글)" required style={{ width: 110 }} aria-label="이름 한글" />
      <input name="nameEn" defaultValue={d?.nameEn} placeholder="Name (EN)" required style={{ width: 110 }} aria-label="이름 영문" />
      <select name="type" defaultValue={d?.type ?? 'MERMAID'} aria-label="종류">
        {TYPES.map(([v, l]) => (
          <option key={v} value={v}>
            {l}
          </option>
        ))}
      </select>
      <input name="sizes" defaultValue={d?.sizes.join(',')} placeholder="44,55,66" required style={{ width: 100 }} aria-label="사이즈" />
      <input name="priceKrw" type="number" min={0} step={1000} defaultValue={d?.priceKrw} placeholder="대여가(원)" required style={{ width: 110 }} aria-label="대여가" />
      <input name="imageUrl" defaultValue={d?.imageUrl ?? ''} placeholder="이미지 주소 (/dress-07.jpg)" style={{ width: 180 }} aria-label="이미지" />
      <input name="sortOrder" type="number" defaultValue={d?.sortOrder ?? 0} style={{ width: 60 }} aria-label="순서" />
      <label style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}>
        <input type="checkbox" name="active" defaultChecked={d ? d.active : true} /> 노출
      </label>
      <button type="submit" className={d ? '' : 'primary'}>{d ? '저장' : '추가'}</button>
    </form>
  );
}

export default async function AdminDresses({ searchParams }: { searchParams: Promise<{ msg?: string }> }) {
  const { msg } = await searchParams;
  const list = await db.select().from(schema.dresses).orderBy(asc(schema.dresses.sortOrder));
  return (
    <div>
      <h1 style={{ fontSize: 28, marginBottom: 8 }}>드레스</h1>
      <p className="muted" style={{ marginTop: 0 }}>
        예약 기록이 있는 드레스는 지우지 말고 &lsquo;노출&rsquo;을 끄세요. 사진은 public 폴더에 넣거나 이미지 주소를 붙여 넣으면 돼요.
      </p>
      {msg && <p className="note">{msg}</p>}
      <div className="card">
        <strong>새 드레스</strong>
        <DressRow />
      </div>
      <div className="card">
        {list.map((d) => (
          <DressRow key={d.id} d={d} />
        ))}
      </div>
    </div>
  );
}
