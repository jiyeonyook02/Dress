import { asc, gte } from 'drizzle-orm';
import { db, schema } from '@/db';
import { kstToday } from '@/lib/dates';
import { addClosedDayAction, removeClosedDayAction } from '../actions';

export default async function AdminClosed({ searchParams }: { searchParams: Promise<{ msg?: string }> }) {
  const { msg } = await searchParams;
  const list = await db.select().from(schema.closedDays).where(gte(schema.closedDays.day, kstToday())).orderBy(asc(schema.closedDays.day));
  return (
    <div>
      <h1 style={{ fontSize: 28, marginBottom: 8 }}>휴무일</h1>
      <p className="muted" style={{ marginTop: 0 }}>휴무일로 지정하면 그 날짜는 예약 화면에서 막혀요. 이미 잡힌 예약은 자동으로 취소되지 않아요.</p>
      {msg && <p className="note">{msg}</p>}
      <div className="card">
        <form action={addClosedDayAction} className="inline">
          <input type="hidden" name="back" value="/admin/closed" />
          <input type="date" name="day" required aria-label="날짜" />
          <input name="reason" placeholder="사유 (선택)" aria-label="사유" />
          <button type="submit" className="primary">추가</button>
        </form>
      </div>
      <div className="card">
        {list.length === 0 && <span className="muted">지정된 휴무일이 없어요</span>}
        {list.map((d) => (
          <form key={d.day} action={removeClosedDayAction} className="inline" style={{ padding: '8px 0', borderBottom: '1px solid var(--line)', width: '100%' }}>
            <input type="hidden" name="day" value={d.day} />
            <input type="hidden" name="back" value="/admin/closed" />
            <span style={{ minWidth: 120 }}>{d.day}</span>
            <span className="muted" style={{ flex: 1 }}>{d.reason}</span>
            <button type="submit">삭제</button>
          </form>
        ))}
      </div>
    </div>
  );
}
