'use server';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { eq } from 'drizzle-orm';
import { z } from 'zod';
import { db, schema } from '@/db';
import { getUser } from '@/lib/session';
import { BookingError, cancelReservation, completeReservation, confirmPaid } from '@/lib/booking';
import { notifyReservation } from '@/lib/notify';
import { DATE_RE } from '@/lib/dates';

async function requireAdmin() {
  const u = await getUser();
  if (!u?.isAdmin) redirect('/login?next=/admin');
  return u;
}

const str = (f: FormData, k: string) => String(f.get(k) ?? '').trim();

function back(f: FormData, msg?: string): never {
  const to = str(f, 'back') || '/admin';
  const path = to.startsWith('/admin') ? to : '/admin';
  revalidatePath('/admin', 'layout');
  if (msg) redirect(`${path}${path.includes('?') ? '&' : '?'}msg=${encodeURIComponent(msg)}`);
  redirect(path);
}

// ── 예약 ────────────────────────────────────────────────
export async function confirmAction(f: FormData) {
  await requireAdmin();
  const id = str(f, 'id');
  try {
    await confirmPaid(id, { payerName: str(f, 'payerName') || null, note: '관리자 확인' });
    await notifyReservation(id, 'confirmed');
  } catch (e) {
    if (e instanceof BookingError) back(f, '확정할 수 없는 상태예요 (만료/취소됨)');
    throw e;
  }
  back(f, '결제 확인 → 예약 확정');
}

export async function cancelAction(f: FormData) {
  await requireAdmin();
  try {
    await cancelReservation(str(f, 'id'), { byAdmin: true });
  } catch (e) {
    if (e instanceof BookingError) back(f, '취소할 수 없는 상태예요');
    throw e;
  }
  back(f, '취소 완료 (결제된 건은 환불 필요로 표시됨)');
}

export async function completeAction(f: FormData) {
  await requireAdmin();
  try {
    await completeReservation(str(f, 'id'));
  } catch (e) {
    if (e instanceof BookingError) back(f, '확정된 예약만 완료 처리할 수 있어요');
    throw e;
  }
  back(f, '이용 완료 처리');
}

export async function memoAction(f: FormData) {
  await requireAdmin();
  await db.update(schema.reservations).set({ adminMemo: str(f, 'memo') || null }).where(eq(schema.reservations.id, str(f, 'id')));
  back(f);
}

export async function refundedAction(f: FormData) {
  await requireAdmin();
  await db.update(schema.payments).set({ status: 'REFUNDED' }).where(eq(schema.payments.id, str(f, 'paymentId')));
  back(f, '환불 완료로 표시');
}

// ── 드레스 ───────────────────────────────────────────────
const DressForm = z.object({
  code: z.string().min(1),
  nameKo: z.string().min(1),
  nameEn: z.string().min(1),
  type: z.enum(['MERMAID', 'ALINE', 'BALLGOWN', 'MINI']),
  sizes: z.array(z.string().min(1)).min(1),
  priceKrw: z.number().int().min(0),
  imageUrl: z.string().nullable(),
  sortOrder: z.number().int(),
  active: z.boolean(),
});

function readDress(f: FormData) {
  return DressForm.safeParse({
    code: str(f, 'code'),
    nameKo: str(f, 'nameKo'),
    nameEn: str(f, 'nameEn'),
    type: str(f, 'type'),
    sizes: str(f, 'sizes')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean),
    priceKrw: Number(str(f, 'priceKrw')),
    imageUrl: str(f, 'imageUrl') || null,
    sortOrder: Number(str(f, 'sortOrder') || 0),
    active: f.get('active') === 'on',
  });
}

export async function saveDressAction(f: FormData) {
  await requireAdmin();
  const parsed = readDress(f);
  if (!parsed.success) back(f, '입력값을 확인하세요');
  const data = parsed.data!;
  const id = str(f, 'id');
  try {
    if (id) await db.update(schema.dresses).set(data).where(eq(schema.dresses.id, id));
    else await db.insert(schema.dresses).values(data);
  } catch {
    back(f, '저장 실패 (번호 중복 등)');
  }
  back(f, '저장됨');
}

// ── 신발 ─────────────────────────────────────────────────
export async function saveShoeAction(f: FormData) {
  await requireAdmin();
  const data = {
    nameKo: str(f, 'nameKo'),
    nameEn: str(f, 'nameEn'),
    heelCm: Number(str(f, 'heelCm') || 0),
    priceKrw: Number(str(f, 'priceKrw') || 0),
    imageUrl: str(f, 'imageUrl') || null,
    sortOrder: Number(str(f, 'sortOrder') || 0),
    active: f.get('active') === 'on',
  };
  if (!data.nameKo || !data.nameEn || Number.isNaN(data.priceKrw)) back(f, '입력값을 확인하세요');
  // "220:1, 225:2" 형식 → 사이즈별 수량
  const stocks = str(f, 'stocks')
    .split(',')
    .map((p) => p.split(':').map((x) => Number(x.trim())))
    .filter(([s, q]) => Number.isInteger(s) && Number.isInteger(q) && s > 0 && q >= 0)
    .map(([size, quantity]) => ({ size, quantity }));

  const id = str(f, 'id');
  await db.transaction(async (tx) => {
    let shoeId = id;
    if (id) await tx.update(schema.shoes).set(data).where(eq(schema.shoes.id, id));
    else shoeId = (await tx.insert(schema.shoes).values(data).returning())[0].id;
    await tx.delete(schema.shoeStocks).where(eq(schema.shoeStocks.shoeId, shoeId));
    if (stocks.length) await tx.insert(schema.shoeStocks).values(stocks.map((s) => ({ ...s, shoeId })));
  });
  back(f, '저장됨');
}

// ── 휴무일 ───────────────────────────────────────────────
export async function addClosedDayAction(f: FormData) {
  await requireAdmin();
  const day = str(f, 'day');
  if (!DATE_RE.test(day)) back(f, '날짜 형식: YYYY-MM-DD');
  await db
    .insert(schema.closedDays)
    .values({ day, reason: str(f, 'reason') || null })
    .onConflictDoNothing();
  back(f, '휴무일 추가됨 (이미 잡힌 예약은 그대로 유지)');
}

export async function removeClosedDayAction(f: FormData) {
  await requireAdmin();
  await db.delete(schema.closedDays).where(eq(schema.closedDays.day, str(f, 'day')));
  back(f, '휴무일 삭제됨');
}
