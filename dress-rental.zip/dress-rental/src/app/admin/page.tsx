import { and, asc, desc, eq, gte, inArray, type SQL } from 'drizzle-orm';
import { db, schema } from '@/db';
import { expirePending } from '@/lib/booking';
import { fmtDay, fmtKst, kstTime, kstToday, DATE_RE } from '@/lib/dates';
import { krw } from '@/lib/money';
import { cancelAction, completeAction, confirmAction, memoAction, refundedAction } from './actions';

const FILTERS = [
  ['PENDING', '결제 대기'],
  ['UPCOMING', '확정 · 다가오는 일정'],
  ['REFUND', '환불 필요'],
  ['ALL', '전체'],
] as const;

const STATUS_KO: Record<string, string> = {
  PENDING: '결제 대기',
  CONFIRMED: '확정',
  COMPLETED: '완료',
  CANCELLED: '취소',
  EXPIRED: '만료',
};
const PAY_KO: Record<string, string> = { BANK: '계좌이체', STORE: '스마트스토어', PAYPAL: 'PayPal' };
const PAYST_KO: Record<string, string> = { PENDING: '대기', PAID: '결제됨', REFUND_NEEDED: '환불 필요', REFUNDED: '환불 완료', VOID: '무효' };

export default async function AdminReservations({ searchParams }: { searchParams: Promise<{ f?: string; date?: string; msg?: string }> }) {
  const sp = await searchParams;
  const f = FILTERS.some(([k]) => k === sp.f) ? sp.f! : 'PENDING';
  const date = sp.date && DATE_RE.test(sp.date) ? sp.date : null;
  await expirePending();

  const R = schema.reservations;
  const where: SQL[] = [];
  if (f === 'PENDING') where.push(eq(R.status, 'PENDING'));
  if (f === 'UPCOMING') where.push(eq(R.status, 'CONFIRMED'), gte(R.fittingDate, kstToday()));
  if (date) where.push(eq(R.fittingDate, date));
  if (f === 'REFUND') {
    const ids = (
      await db.select({ id: schema.payments.reservationId }).from(schema.payments).where(eq(schema.payments.status, 'REFUND_NEEDED'))
    ).map((r) => r.id);
    where.push(inArray(R.id, ids.length ? ids : ['-']));
  }

  const rows = await db.query.reservations.findMany({
    where: where.length ? and(...where) : undefined,
    orderBy: f === 'ALL' ? desc(R.createdAt) : asc(R.fittingAt),
    limit: 300,
    with: { user: true, dress: true, shoe: true, payments: true },
  });
  const backUrl = `/admin?f=${f}${date ? `&date=${date}` : ''}`;

  return (
    <div>
      <h1 style={{ fontSize: 28, marginBottom: 16 }}>예약 관리</h1>
      {sp.msg && <p className="note" style={{ marginBottom: 16 }}>{sp.msg}</p>}
      <div className="filters">
        {FILTERS.map(([k, label]) => (
          <a key={k} href={`/admin?f=${k}${date ? `&date=${date}` : ''}`} aria-current={f === k}>
            {label}
          </a>
        ))}
        <form method="get" action="/admin" className="inline" style={{ marginLeft: 'auto' }}>
          <input type="hidden" name="f" value={f} />
          <input type="date" name="date" defaultValue={date ?? ''} aria-label="피팅 날짜" />
          <button type="submit">날짜로 보기</button>
          {date && <a href={`/admin?f=${f}`}>날짜 해제</a>}
        </form>
      </div>

      <div className="tbl">
        <table>
          <thead>
            <tr>
              <th>예약번호</th>
              <th>피팅</th>
              <th>고객</th>
              <th>드레스 / 신발</th>
              <th>결제</th>
              <th>상태</th>
              <th>처리</th>
              <th>메모</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr>
                <td colSpan={8} style={{ padding: 32, textAlign: 'center', color: 'var(--muted)' }}>
                  해당하는 예약이 없어요
                </td>
              </tr>
            )}
            {rows.map((r) => {
              const p = r.payments[0];
              return (
                <tr key={r.id}>
                  <td>
                    <a href={`/book/done/${r.code}`} style={{ textDecoration: 'underline' }}>{r.code}</a>
                    <div className="muted">{fmtKst(r.createdAt)} 접수</div>
                  </td>
                  <td style={{ whiteSpace: 'nowrap' }}>
                    {fmtDay(r.fittingDate)} {kstTime(r.fittingAt)}
                  </td>
                  <td>
                    {r.user.name ?? '-'}
                    <div className="muted">{r.user.email ?? '(카카오 · 이메일 없음)'}</div>
                    <div className="muted">{r.locale === 'en' ? 'EN' : 'KO'}</div>
                  </td>
                  <td>
                    {r.dress.code} · {r.dressSize}
                    <div className="muted">{r.shoe ? `${r.shoe.nameKo} · ${r.shoeSize}mm` : '신발 없음'}</div>
                  </td>
                  <td style={{ whiteSpace: 'nowrap' }}>
                    {PAY_KO[r.payMethod]}
                    <div>{p?.currency === 'USD' ? `USD ${p.amount}` : krw(r.amountKrw)}</div>
                    {p && <div className="muted">{PAYST_KO[p.status]}{p.payerName ? ` · ${p.payerName}` : ''}</div>}
                    {p?.note && <div className="muted">{p.note}</div>}
                  </td>
                  <td style={{ whiteSpace: 'nowrap' }}>
                    {STATUS_KO[r.status]}
                    {r.status === 'PENDING' && <div className="muted">기한 {fmtKst(r.dueAt)}</div>}
                  </td>
                  <td>
                    <div className="row-actions">
                      {r.status === 'PENDING' && (
                        <form action={confirmAction} className="inline">
                          <input type="hidden" name="id" value={r.id} />
                          <input type="hidden" name="back" value={backUrl} />
                          <input name="payerName" placeholder="입금자명" style={{ width: 90 }} aria-label="입금자명" />
                          <button type="submit" className="primary">입금 확인 · 확정</button>
                        </form>
                      )}
                      {r.status === 'CONFIRMED' && (
                        <form action={completeAction}>
                          <input type="hidden" name="id" value={r.id} />
                          <input type="hidden" name="back" value={backUrl} />
                          <button type="submit">이용 완료</button>
                        </form>
                      )}
                      {(r.status === 'PENDING' || r.status === 'CONFIRMED') && (
                        <form action={cancelAction}>
                          <input type="hidden" name="id" value={r.id} />
                          <input type="hidden" name="back" value={backUrl} />
                          <button type="submit">취소</button>
                        </form>
                      )}
                      {p?.status === 'REFUND_NEEDED' && (
                        <form action={refundedAction}>
                          <input type="hidden" name="paymentId" value={p.id} />
                          <input type="hidden" name="back" value={backUrl} />
                          <button type="submit">환불 완료 표시</button>
                        </form>
                      )}
                    </div>
                  </td>
                  <td>
                    <form action={memoAction} className="inline">
                      <input type="hidden" name="id" value={r.id} />
                      <input type="hidden" name="back" value={backUrl} />
                      <input name="memo" defaultValue={r.adminMemo ?? ''} style={{ width: 140 }} aria-label="메모" />
                      <button type="submit">저장</button>
                    </form>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
