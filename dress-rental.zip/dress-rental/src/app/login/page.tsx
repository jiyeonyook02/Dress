import { redirect } from 'next/navigation';
import { getDict } from '@/lib/locale';
import { getUser } from '@/lib/session';
import { safeNext } from '@/lib/http';
import { LoginForm } from '@/components/LoginForm';
import { kakao } from '@/lib/config';

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string; gate?: string; error?: string }>;
}) {
  const sp = await searchParams;
  const next = safeNext(sp.next, '/');
  if (await getUser()) redirect(next);
  const { locale, t } = await getDict();

  return (
    <main className="page">
      <div className="narrow">
        <div className="center stack-s">
          <span className="caps muted">Sign in</span>
          <h1 style={{ fontSize: 36 }}>{t.loginTitle}</h1>
          {(sp.gate || next.startsWith('/book')) && <p className="note">{t.gate}</p>}
          {sp.error === 'KAKAO' && <p className="err">{t.errKakao}</p>}
        </div>
        <LoginForm t={t} locale={locale} next={next} kakaoEnabled={Boolean(kakao.restApiKey)} />
      </div>
    </main>
  );
}
