import { LegalPage } from '@/components/LegalPage';

export default function Refund() {
  return (
    <LegalPage
      titleKey="refundPolicy"
      bodyKo={['피팅 [N]일 전까지 전액 환불, 이후 [환불 규정].', '결제 대기 중인 예약은 마이페이지에서 직접 취소할 수 있어요. 결제 후 취소는 담당자에게 문의해 주세요.']}
      bodyEn={[
        'Full refund up to [N] days before your fitting; after that, [refund policy].',
        'Unpaid reservations can be cancelled in My Page. For paid reservations, please contact us.',
      ]}
    />
  );
}
