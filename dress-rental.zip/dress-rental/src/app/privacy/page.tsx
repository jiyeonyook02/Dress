import { LegalPage } from '@/components/LegalPage';

export default function Privacy() {
  return (
    <LegalPage
      titleKey="privacy"
      bodyKo={[
        '수집 항목: 이메일, 이름(닉네임), 카카오 회원번호, 예약·결제 기록',
        '이용 목적: 예약 확인, 결제 확인, 예약 관련 안내',
        '보관 기간: [기간 입력]',
        '[개인정보처리방침 나머지 내용을 넣어 주세요]',
      ]}
      bodyEn={[
        'We collect: email, name (nickname), Kakao member ID, reservation and payment records.',
        'Purpose: confirming reservations and payments, and sending booking notices.',
        'Retention: [period]',
        '[Rest of privacy policy]',
      ]}
    />
  );
}
