# DB 관리 가이드

DB는 PostgreSQL이에요.

- 표 정의: `src/db/schema.ts`
- 실제로 DB에 적용된 변경 기록: `drizzle/*.sql`

## 표 한눈에 보기

| 표 | 들어있는 것 | 누가 바꾸나 |
| --- | --- | --- |
| `users` | 회원 (이메일, 카카오 회원번호, 이름, 가입 방식) | 로그인할 때 자동 |
| `email_codes` | 이메일 인증번호 (번호 자체가 아니라 해시만) | 자동, 오래된 건 지워도 됨 |
| `dresses` | 드레스 (번호, 이름 KO/EN, 종류, 사이즈 목록, 대여가, 사진, 노출 여부) | 관리자 `/admin/dresses` |
| `shoes` | 신발 (이름, 굽, 대여가, 사진, 노출 여부) | 관리자 `/admin/shoes` |
| `shoe_stocks` | 신발 사이즈별 보유 수량 | 관리자 `/admin/shoes` |
| `reservations` | 예약 (예약번호, 고객, 피팅 일시, 드레스·사이즈, 신발, 결제수단, 금액, 상태, 결제 기한, 메모) | 고객 예약 / 관리자 |
| `payments` | 결제 기록 (수단, 금액, 통화, 상태, 입금자명, PayPal 주문번호와 응답 원본) | 자동 / 관리자 |
| `slot_locks` | **시간대 잠금**: 활성 예약 1건당 1행 | 자동 (손대지 않기) |
| `dress_day_locks` | **드레스 날짜 잠금**: 예약일 ± `DRESS_BUFFER_DAYS`일만큼 행 | 자동 (손대지 않기) |
| `closed_days` | 쇼룸 휴무일 | 관리자 `/admin/closed` |

### 예약 상태 (`reservations.status`)

`PENDING`(결제 대기) → `CONFIRMED`(확정) → `COMPLETED`(이용 완료)

중간에 끝나는 경우:
- `CANCELLED`: 고객 또는 관리자가 취소
- `EXPIRED`: 결제 기한이 지나 자동 취소

### 결제 상태 (`payments.status`)

| 상태 | 뜻 |
| --- | --- |
| `PENDING` | 결제 기다리는 중 |
| `PAID` | 결제됨 |
| `VOID` | 결제 전에 취소·만료됨 |
| `REFUND_NEEDED` | 결제 후 취소됨 → 환불해야 함 |
| `REFUNDED` | 환불 완료 |

## 중복 예약은 어떻게 막나

"빈자리 확인 후 저장" 방식은 두 사람이 동시에 누르면 둘 다 통과할 수 있어요. 그래서 **DB 자체가 거부**하게 만들었어요.

- `slot_locks`는 피팅 시각이 기본키예요. 같은 시각으로 두 번째 행을 넣으면 DB가 오류를 내요. 그 예약은 "다른 시간을 선택해 주세요"로 돌아가요.
- `dress_day_locks`는 (드레스, 날짜)가 기본키예요.
  - 10/20에 버퍼 2일로 예약하면 10/18~10/22 다섯 행이 생겨요.
  - 그 기간과 하루라도 겹치는 같은 드레스 예약은 DB가 거부해요.
- 신발은 사이즈별 수량이 여러 개일 수 있어서 잠금 표 대신 개수를 세요. 예약 저장은 가장 엄격한 격리 수준(serializable)으로 돌리고, 충돌이 나면 다시 시도해요.
- 잠금 행은 예약이 활성(`PENDING`/`CONFIRMED`)일 때만 있어요. 취소·만료·완료되면 지워져서 자리가 다시 열려요.

`npm run test:booking`을 돌리면 이 규칙을 실제 DB로 확인해요. 6명이 동시에 같은 시간에 예약해도 1명만 성공하는지까지 봐요.

## 매일 하는 관리 (관리자 페이지)

`.env`의 `ADMIN_EMAILS`에 있는 이메일로 로그인한 뒤 `/admin`으로 가요.

- **결제 대기** 탭: 입금이 들어온 예약에 입금자명을 적고 [입금 확인 · 확정]을 눌러요. 기한이 지난 건은 자동으로 빠져요.
- **확정 · 다가오는 일정** 탭: 날짜로 걸러서 그날 피팅 명단을 봐요. 대여가 끝나면 [이용 완료]를 눌러요.
- **환불 필요** 탭: 결제 후 취소된 건이에요. 직접 환불한 뒤 [환불 완료 표시]를 눌러요.
- **메모**: 예약마다 내부 메모를 남길 수 있어요 (고객에게는 안 보여요).
- **드레스 / 신발**: 가격, 사이즈, 사진, 노출 여부를 바꿔요. 예약 기록이 있는 상품은 지우지 말고 "노출"을 꺼요.
- **휴무일**: 지정한 날짜는 예약 화면에서 막혀요. 이미 잡힌 예약은 그대로라서 고객에게 따로 연락하세요.
- **예약 CSV 내려받기**: 전체 예약을 엑셀로 열 수 있는 파일로 받아요.

## 표를 직접 보고 고치기 (Drizzle Studio)

```bash
npm run db:studio
```

브라우저에서 표를 엑셀처럼 보고 고칠 수 있어요. 다만 **잠금 표(`slot_locks`, `dress_day_locks`)와 예약 상태는 직접 고치지 마세요.**

- 상태를 바꿀 때는 관리자 페이지 버튼을 쓰세요. 버튼은 상태, 결제 기록, 잠금을 한 번에 같이 바꿔요.
- 운영 DB에 붙을 때는 `DATABASE_URL`을 운영 주소로 바꿔서 실행해요.

### 자주 쓰는 조회 (SQL)

```sql
-- 이번 주 확정된 피팅 명단
select r.code, r.fitting_date, to_char(r.fitting_at at time zone 'Asia/Seoul', 'HH24:MI') as time,
       u.name, u.email, d.code as dress, r.dress_size
from reservations r join users u on u.id = r.user_id join dresses d on d.id = r.dress_id
where r.status = 'CONFIRMED' and r.fitting_date between current_date and current_date + 7
order by r.fitting_at;

-- 월별 매출 (확정 + 완료)
select to_char(fitting_date, 'YYYY-MM') as month, count(*), sum(amount_krw)
from reservations where status in ('CONFIRMED', 'COMPLETED') group by 1 order by 1;

-- 드레스별 인기 순위
select d.code, count(*) from reservations r join dresses d on d.id = r.dress_id
where r.status in ('CONFIRMED', 'COMPLETED') group by d.code order by 2 desc;

-- 오래된 인증번호 정리 (선택)
delete from email_codes where created_at < now() - interval '7 days';
```

## DB 구조를 바꿀 때

예를 들어 드레스에 "색상" 칸을 추가하고 싶다면 이렇게 해요.

1. `src/db/schema.ts`의 `dresses`에 `color: text('color')`를 추가해요.
2. `npm run db:generate` → `drizzle/` 폴더에 변경 SQL 파일이 생겨요. 내용을 한번 읽어보세요.
3. `npm run db:migrate` → 내 로컬 DB에 적용돼요.
4. 이상 없으면 git에 커밋하고, 운영 DB에는 `DATABASE_URL=<운영 주소> npm run db:migrate`로 적용해요.

주의할 점:
- **이미 적용된 `drizzle/*.sql` 파일은 고치거나 지우지 마세요.** 바꾸려면 새 변경을 하나 더 만드세요.
- 칸 이름을 바꾸거나 지우는 변경은 데이터가 사라질 수 있어요. 적용 전에 꼭 백업하세요.

## 백업과 복구

**운영 DB 업체 백업을 먼저 켜두세요.** Neon과 Supabase 모두 시점 복구(PITR) 기능이 있어요. 요금제마다 보관 기간이 달라요.

추가로 직접 백업 파일을 남기려면 (PostgreSQL의 `pg_dump`가 깔려 있어야 해요):

```bash
npm run db:backup                     # backups/dress-날짜.dump 생성 (git에는 안 올라감)
```

복구하는 법:

```bash
pg_restore --clean --if-exists --no-owner -d "$DATABASE_URL" backups/dress-20261006-120000.dump
```

추천 습관:
- 큰 변경(마이그레이션, 대량 수정) 전에 한 번 백업해요.
- 한 달에 한 번은 백업 파일을 다른 곳(구글 드라이브 등)에 복사해 둬요.

## 개인정보

- 저장하는 개인정보: 이메일, 이름(닉네임), 카카오 회원번호, 예약·결제 기록, PayPal 응답 원본(결제자 이름·이메일 포함).
- 인증번호는 해시로만 저장하고, 카드번호 같은 결제 정보는 저장하지 않아요.
- 개인정보처리방침(`/privacy`)에 위 항목과 보관 기간을 적어 두세요.
- 탈퇴 요청이 오면 그 회원의 예약 기록을 어떻게 처리할지 정해 두세요 (보관 의무 기간이 지나면 삭제 등).
