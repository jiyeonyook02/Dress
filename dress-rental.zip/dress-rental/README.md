# [BRAND] 드레스 대여 · 피팅 예약 사이트

로그인한 고객만 피팅을 예약할 수 있는 드레스 대여 사이트입니다.

- 예약 흐름: 시간 → 드레스(사이즈) → 신발 → 결제 → 완료
- 결제 방식: 국내는 계좌이체·스마트스토어, 해외는 PayPal
- 중복 방지: 이미 잡힌 시간대와 드레스는 다른 사람이 고를 수 없어요. 동시에 눌러도 한 명만 성공합니다.
- 화면 언어: 한국어 / English 전환
- 관리자 페이지(`/admin`): 입금 확인 → 예약 확정, 드레스·신발·휴무일 관리, 예약 CSV 내려받기

| 문서 | 내용 |
| --- | --- |
| [docs/PAYMENTS.md](docs/PAYMENTS.md) | 결제 방식별로 돈이 어떻게 들어오고 예약이 어떻게 확정되는지 |
| [docs/DB.md](docs/DB.md) | DB 표 구조, 매일 관리하는 법, 백업·복구, 구조 바꾸는 법 |

## 기술 구성

- Next.js 15 (App Router) + TypeScript
- PostgreSQL + Drizzle ORM (마이그레이션 SQL은 `drizzle/` 폴더)
- 로그인: 카카오 OAuth, 이메일 6자리 인증번호. 세션은 서명된 쿠키(JWT)
- 메일: SMTP (nodemailer)
- 배포 예시: Vercel + Neon(또는 Supabase) PostgreSQL

## 처음 실행하기 (내 컴퓨터)

준비물: Node.js 20.12 이상, Docker (로컬 DB용)

```bash
npm install
cp .env.example .env          # 값 채우기 (아래 표 참고)
docker compose up -d          # 로컬 PostgreSQL 실행
npm run db:migrate            # 표 만들기
npm run db:seed               # 예시 드레스 6벌·신발 3종 넣기
npm run dev                   # http://localhost:3000
```

- SMTP를 비워두면 이메일 인증번호가 메일로 가지 않고 **터미널에 찍혀요** (개발 중에만).
- `.env`의 `ADMIN_EMAILS`에 적은 이메일로 로그인하면 `/admin`에 들어갈 수 있어요.
- 예약 로직 테스트: `npm run test:booking` (동시 예약, 취소, 만료, 재고를 실제 DB로 확인)

## 환경변수 (.env)

| 이름 | 설명 |
| --- | --- |
| `SITE_URL` | 사이트 주소. 카카오·PayPal이 돌아올 주소에 쓰여요 |
| `DATABASE_URL` | PostgreSQL 접속 주소 |
| `AUTH_SECRET` | 로그인 쿠키 서명용 긴 랜덤 문자열 (`openssl rand -base64 32`) |
| `ADMIN_EMAILS` | 관리자 이메일 (쉼표로 여러 개) |
| `KAKAO_REST_API_KEY`, `KAKAO_CLIENT_SECRET` | 카카오 로그인. 비우면 카카오 버튼이 숨겨져요 |
| `SMTP_*`, `MAIL_FROM` | 인증번호와 예약 안내 메일 발송 |
| `BOOKABLE_DAYS` | 오늘부터 며칠 뒤까지 예약 가능한지 (기본 30) |
| `DRESS_BUFFER_DAYS` | 드레스 1회 대여가 예약일 앞뒤로 며칠을 차지하는지 (기본 2) |
| `HOLD_HOURS` | 결제 대기 유지 시간. 지나면 자동 취소 (기본 24) |
| `BANK_*` | 계좌이체 정보. 비우면 계좌이체 선택지가 숨겨져요 |
| `SMARTSTORE_URL` | 스마트스토어 예약금 상품 링크. 비우면 숨겨져요 |
| `PAYPAL_*` | PayPal 설정 ([docs/PAYMENTS.md](docs/PAYMENTS.md) 참고). 비우면 숨겨져요 |
| `CRON_SECRET` | 자동 만료 작업 호출용 비밀값 |

피팅 시간대(11:00, 12:30 …)는 `src/lib/config.ts`의 `SLOT_TIMES`에서 바꿔요.
상호·연락처·주소는 `src/content/site.ts`, 화면 문구는 `src/lib/i18n.ts`에서 바꿔요.

## 카카오 로그인 설정

1. [developers.kakao.com](https://developers.kakao.com)에서 애플리케이션을 만들어요.
2. 플랫폼 → Web에 사이트 도메인을 등록해요.
3. 카카오 로그인을 활성화하고, Redirect URI에 `{SITE_URL}/api/auth/kakao/callback`을 등록해요.
4. 동의항목에서 닉네임을 켜요. 이메일까지 받으려면 비즈 앱 전환이나 검수가 필요할 수 있어요.
5. REST API 키를 `KAKAO_REST_API_KEY`에 넣어요. 클라이언트 시크릿은 기본으로 켜져 있으니, 보안 메뉴에서 시크릿 값을 복사해 `KAKAO_CLIENT_SECRET`에도 꼭 넣어요 (안 넣으면 로그인 실패).

카카오에서 이메일을 받지 못한 회원은 예약 안내 메일이 가지 않아요. 마이페이지에서는 예약을 확인할 수 있어요.

## 배포 (Vercel + Neon 예시)

1. 이 저장소를 GitHub에 올려요 (아래 "Git에 올리기").
2. Neon(또는 Supabase)에서 PostgreSQL을 만들고 접속 주소를 복사해요.
3. 내 컴퓨터에서 `DATABASE_URL=<운영 주소> npm run db:migrate`로 운영 DB에 표를 만들어요. 필요하면 `npm run db:seed`도 실행해요.
4. Vercel에서 GitHub 저장소를 가져오고, Environment Variables에 `.env` 값을 똑같이 넣어요. 이때 `SITE_URL`은 실제 주소로 넣어요.
5. `vercel.json`의 cron이 하루 한 번 만료 작업을 돌려요.
   - Vercel이 `CRON_SECRET`을 자동으로 붙여서 호출해요.
   - 사이트에 접속할 때마다도 만료 처리가 돌아서, cron 주기가 길어도 빈자리 표시는 정확해요.

## Git에 올리기

```bash
git remote add origin https://github.com/<아이디>/<저장소이름>.git
git branch -M main
git push -u origin main
```

`.env`(비밀번호·키)는 `.gitignore`에 들어 있어서 올라가지 않아요. 운영 비밀값은 Vercel 환경변수에만 넣으세요.

## 폴더 구조

```
src/
  app/                 화면과 API
    page.tsx           홈 (예약창 포함)
    book/              예약 단계, 완료(결제 안내) 화면
    my/                마이페이지
    login/             로그인
    admin/             관리자 (예약·드레스·신발·휴무일)
    api/               로그인·예약·PayPal·cron API
  components/          화면 조각 (사이드메뉴, 예약 흐름 등)
  db/schema.ts         DB 표 정의
  lib/booking.ts       예약 핵심 로직 (중복 방지, 취소, 만료, 확정)
  lib/paypal.ts        PayPal 연동
  lib/i18n.ts          한국어/영어 문구
drizzle/               DB 마이그레이션 SQL
scripts/               시드, 백업, 예약 테스트
docs/                  DB 관리법, 결제 흐름
```
