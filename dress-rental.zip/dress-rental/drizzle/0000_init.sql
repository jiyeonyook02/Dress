CREATE TYPE "public"."auth_provider" AS ENUM('KAKAO', 'EMAIL');--> statement-breakpoint
CREATE TYPE "public"."dress_type" AS ENUM('MERMAID', 'ALINE', 'BALLGOWN', 'MINI');--> statement-breakpoint
CREATE TYPE "public"."pay_method" AS ENUM('BANK', 'STORE', 'PAYPAL');--> statement-breakpoint
CREATE TYPE "public"."payment_status" AS ENUM('PENDING', 'PAID', 'REFUND_NEEDED', 'REFUNDED', 'VOID');--> statement-breakpoint
CREATE TYPE "public"."reservation_status" AS ENUM('PENDING', 'CONFIRMED', 'COMPLETED', 'CANCELLED', 'EXPIRED');--> statement-breakpoint
CREATE TABLE "closed_days" (
	"day" date PRIMARY KEY NOT NULL,
	"reason" text
);
--> statement-breakpoint
CREATE TABLE "dress_day_locks" (
	"dress_id" text NOT NULL,
	"day" date NOT NULL,
	"reservation_id" text NOT NULL,
	CONSTRAINT "dress_day_locks_pk" PRIMARY KEY("dress_id","day")
);
--> statement-breakpoint
CREATE TABLE "dresses" (
	"id" text PRIMARY KEY NOT NULL,
	"code" text NOT NULL,
	"name_ko" text NOT NULL,
	"name_en" text NOT NULL,
	"type" "dress_type" NOT NULL,
	"sizes" text[] NOT NULL,
	"price_krw" integer NOT NULL,
	"image_url" text,
	"active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "dresses_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "email_codes" (
	"id" text PRIMARY KEY NOT NULL,
	"email" text NOT NULL,
	"code_hash" text NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"attempts" integer DEFAULT 0 NOT NULL,
	"used_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payments" (
	"id" text PRIMARY KEY NOT NULL,
	"reservation_id" text NOT NULL,
	"method" "pay_method" NOT NULL,
	"status" "payment_status" DEFAULT 'PENDING' NOT NULL,
	"amount" numeric(12, 2) NOT NULL,
	"currency" text DEFAULT 'KRW' NOT NULL,
	"external_id" text,
	"payer_name" text,
	"note" text,
	"raw" jsonb,
	"paid_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "payments_external_id_unique" UNIQUE("external_id")
);
--> statement-breakpoint
CREATE TABLE "reservations" (
	"id" text PRIMARY KEY NOT NULL,
	"code" text NOT NULL,
	"user_id" text NOT NULL,
	"fitting_at" timestamp with time zone NOT NULL,
	"fitting_date" date NOT NULL,
	"dress_id" text NOT NULL,
	"dress_size" text NOT NULL,
	"shoe_id" text,
	"shoe_size" integer,
	"pay_method" "pay_method" NOT NULL,
	"amount_krw" integer NOT NULL,
	"status" "reservation_status" DEFAULT 'PENDING' NOT NULL,
	"due_at" timestamp with time zone NOT NULL,
	"locale" text DEFAULT 'ko' NOT NULL,
	"admin_memo" text,
	"confirmed_at" timestamp with time zone,
	"cancelled_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "reservations_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "shoe_stocks" (
	"id" text PRIMARY KEY NOT NULL,
	"shoe_id" text NOT NULL,
	"size" integer NOT NULL,
	"quantity" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "shoes" (
	"id" text PRIMARY KEY NOT NULL,
	"name_ko" text NOT NULL,
	"name_en" text NOT NULL,
	"heel_cm" integer NOT NULL,
	"price_krw" integer NOT NULL,
	"image_url" text,
	"active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "slot_locks" (
	"fitting_at" timestamp with time zone PRIMARY KEY NOT NULL,
	"reservation_id" text NOT NULL,
	CONSTRAINT "slot_locks_reservation_id_unique" UNIQUE("reservation_id")
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" text PRIMARY KEY NOT NULL,
	"email" text,
	"kakao_id" text,
	"name" text,
	"provider" "auth_provider" NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "users_email_unique" UNIQUE("email"),
	CONSTRAINT "users_kakao_id_unique" UNIQUE("kakao_id")
);
--> statement-breakpoint
ALTER TABLE "dress_day_locks" ADD CONSTRAINT "dress_day_locks_dress_id_dresses_id_fk" FOREIGN KEY ("dress_id") REFERENCES "public"."dresses"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "dress_day_locks" ADD CONSTRAINT "dress_day_locks_reservation_id_reservations_id_fk" FOREIGN KEY ("reservation_id") REFERENCES "public"."reservations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_reservation_id_reservations_id_fk" FOREIGN KEY ("reservation_id") REFERENCES "public"."reservations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reservations" ADD CONSTRAINT "reservations_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reservations" ADD CONSTRAINT "reservations_dress_id_dresses_id_fk" FOREIGN KEY ("dress_id") REFERENCES "public"."dresses"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reservations" ADD CONSTRAINT "reservations_shoe_id_shoes_id_fk" FOREIGN KEY ("shoe_id") REFERENCES "public"."shoes"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shoe_stocks" ADD CONSTRAINT "shoe_stocks_shoe_id_shoes_id_fk" FOREIGN KEY ("shoe_id") REFERENCES "public"."shoes"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "slot_locks" ADD CONSTRAINT "slot_locks_reservation_id_reservations_id_fk" FOREIGN KEY ("reservation_id") REFERENCES "public"."reservations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "dress_day_locks_resv_idx" ON "dress_day_locks" USING btree ("reservation_id");--> statement-breakpoint
CREATE INDEX "email_codes_email_idx" ON "email_codes" USING btree ("email","created_at");--> statement-breakpoint
CREATE INDEX "payments_resv_idx" ON "payments" USING btree ("reservation_id");--> statement-breakpoint
CREATE INDEX "reservations_status_due_idx" ON "reservations" USING btree ("status","due_at");--> statement-breakpoint
CREATE INDEX "reservations_date_idx" ON "reservations" USING btree ("fitting_date");--> statement-breakpoint
CREATE INDEX "reservations_user_idx" ON "reservations" USING btree ("user_id");--> statement-breakpoint
CREATE UNIQUE INDEX "shoe_stocks_shoe_size_uq" ON "shoe_stocks" USING btree ("shoe_id","size");