#!/usr/bin/env bash
# DB 전체를 backups/ 폴더에 파일 하나로 저장 (pg_dump 필요)
# 사용: npm run db:backup
# 되돌리기: pg_restore --clean --if-exists -d "$DATABASE_URL" backups/파일이름.dump
set -euo pipefail
cd "$(dirname "$0")/.."
if [ -f .env ]; then set -a; . ./.env; set +a; fi
: "${DATABASE_URL:?DATABASE_URL 이 필요합니다}"
mkdir -p backups
OUT="backups/dress-$(date +%Y%m%d-%H%M%S).dump"
pg_dump --format=custom --no-owner --dbname="${DATABASE_URL%%\?*}" --file="$OUT"
echo "저장됨: $OUT"
