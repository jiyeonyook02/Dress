// 예약 중복 방지·취소·만료·결제확정이 제대로 되는지 실제 DB로 확인하는 테스트.
// 실행: npm run test:booking   (테스트 데이터는 끝나면 지움)
import assert from 'node:assert/strict';
import { eq, inArray } from 'drizzle-orm';
import { db, schema } from '../src/db';
import {
  bookableRange,
  BookingError,
  cancelReservation,
  confirmPaid,
  createReservation,
  expirePending,
  getAvailability,
} from '../src/lib/booking';
import { addDays } from '../src/lib/dates';

const created: string[] = [];
const users: string[] = [];

async function code(p: Promise<unknown>) {
  try {
    const r = (await p) as { id: string };
    created.push(r.id);
    return 'OK';
  } catch (e) {
    if (e instanceof BookingError) return e.code;
    throw e;
  }
}

async function main() {
  const [u1] = await db.insert(schema.users).values({ email: `t1-${Date.now()}@test.local`, provider: 'EMAIL' }).returning();
  const [u2] = await db.insert(schema.users).values({ email: `t2-${Date.now()}@test.local`, provider: 'EMAIL' }).returning();
  users.push(u1.id, u2.id);

  const ds = await db.select().from(schema.dresses).orderBy(schema.dresses.sortOrder);
  const [shoe] = await db.select().from(schema.shoes).orderBy(schema.shoes.sortOrder);
  const day = addDays(bookableRange().first, 10);
  const base = { date: day, dressSize: '55', shoeId: null, shoeSize: null, payMethod: 'BANK' as const, agree: true as const };
  const dA = ds.find((d) => d.sizes.includes('55'))!;
  const dB = ds.find((d) => d.id !== dA.id && d.sizes.includes('55'))!;

  // 1) 같은 시간대에 두 명이 동시에 → 한 명만 성공
  const r1 = await Promise.all([
    code(createReservation({ ...base, time: '11:00', dressId: dA.id }, u1.id, 'ko')),
    code(createReservation({ ...base, time: '11:00', dressId: dB.id }, u2.id, 'ko')),
  ]);
  assert.deepEqual([...r1].sort(), ['OK', 'SLOT']);
  console.log('✓ 같은 시간대 동시 예약 → 한 명만 성공', r1);

  // 2) 이미 잡힌 드레스를 버퍼 기간 안 다른 날에 → 거부
  const winner = r1[0] === 'OK' ? dA : dB;
  const r2 = await code(createReservation({ ...base, date: addDays(day, 1), time: '14:00', dressId: winner.id }, u2.id, 'ko'));
  assert.equal(r2, 'DRESS');
  console.log('✓ 버퍼 기간 안 같은 드레스 → DRESS');

  // 화면에서도 불가로 표시되는지
  const av = await getAvailability(day);
  assert.equal(av.slots.find((s) => s.time === '11:00')!.available, false);
  assert.equal(av.dresses.find((d) => d.id === winner.id)!.available, false);
  console.log('✓ 빈자리 조회에 반영됨');

  // 3) 취소하면 다시 열림
  await cancelReservation(created[0], { byAdmin: false, userId: r1[0] === 'OK' ? u1.id : u2.id });
  const r3 = await code(createReservation({ ...base, time: '11:00', dressId: winner.id }, u2.id, 'ko'));
  assert.equal(r3, 'OK');
  console.log('✓ 취소 후 같은 시간·드레스 재예약 가능');

  // 4) 결제 기한 지나면 자동 만료 → 잠금 해제
  const last = created[created.length - 1];
  await db.update(schema.reservations).set({ dueAt: new Date(Date.now() - 1000) }).where(eq(schema.reservations.id, last));
  const n = await expirePending();
  assert.ok(n >= 1);
  const [exp] = await db.select().from(schema.reservations).where(eq(schema.reservations.id, last));
  assert.equal(exp.status, 'EXPIRED');
  const locks = await db.select().from(schema.slotLocks).where(eq(schema.slotLocks.reservationId, last));
  assert.equal(locks.length, 0);
  console.log('✓ 기한 지난 예약 자동 만료 + 잠금 해제');

  // 5) 신발 재고 1켤레 → 두 번째는 거부
  const r5a = await code(createReservation({ ...base, time: '15:30', dressId: dA.id, shoeId: shoe.id, shoeSize: 235 }, u1.id, 'ko'));
  const r5b = await code(
    createReservation({ ...base, date: addDays(day, 8), time: '15:30', dressId: dB.id, shoeId: shoe.id, shoeSize: 235 }, u2.id, 'ko'),
  );
  const r5c = await code(createReservation({ ...base, time: '17:00', dressId: dB.id, shoeId: shoe.id, shoeSize: 235 }, u2.id, 'ko'));
  assert.equal(r5a, 'OK');
  assert.equal(r5b, 'OK'); // 기간 밖이라 가능
  assert.equal(r5c, 'SHOE');
  console.log('✓ 신발 사이즈 재고 초과 → SHOE');

  // 6) 결제 확인 → 확정
  const toConfirm = created[created.length - 2];
  const c = await confirmPaid(toConfirm, { payerName: '홍길동' });
  assert.equal(c.status, 'CONFIRMED');
  const [p] = await db.select().from(schema.payments).where(eq(schema.payments.reservationId, toConfirm));
  assert.equal(p.status, 'PAID');
  // 확정 후 고객은 직접 취소 불가, 관리자는 가능 → 결제는 환불 필요로
  const userCancel = await code(cancelReservation(toConfirm, { byAdmin: false, userId: u1.id }) as Promise<never>);
  assert.equal(userCancel, 'STATE');
  await cancelReservation(toConfirm, { byAdmin: true });
  const [p2] = await db.select().from(schema.payments).where(eq(schema.payments.reservationId, toConfirm));
  assert.equal(p2.status, 'REFUND_NEEDED');
  console.log('✓ 결제 확인 → 확정 / 확정 후 관리자 취소 → 환불 필요 표시');

  // 7) 동시에 10명이 같은 시간대 → 정확히 1명
  const many = await Promise.all(
    ds.slice(0, 6).map((d, i) =>
      code(createReservation({ ...base, date: addDays(day, 15), time: '18:30', dressId: d.id, dressSize: d.sizes[0] }, i % 2 ? u1.id : u2.id, 'ko')),
    ),
  );
  assert.equal(many.filter((x) => x === 'OK').length, 1);
  console.log('✓ 6명 동시 요청 → 1명만 성공', many);

  console.log('\n모든 테스트 통과');
}

main()
  .catch((e) => {
    console.error('테스트 실패:', e);
    process.exitCode = 1;
  })
  .finally(async () => {
    // 테스트 데이터 정리
    const ids = (
      await db.select({ id: schema.reservations.id }).from(schema.reservations).where(inArray(schema.reservations.userId, users))
    ).map((r) => r.id);
    if (ids.length) await db.delete(schema.reservations).where(inArray(schema.reservations.id, ids));
    if (users.length) await db.delete(schema.users).where(inArray(schema.users.id, users));
    process.exit();
  });
