// 처음 시작할 때 넣는 예시 데이터. 가격·이름은 관리자 페이지(/admin)에서 바꾸면 됨.
import { db, schema } from '../src/db';

const SAMPLE_DRESS_PRICE = 150000; // 예시 가격
const SAMPLE_SHOE_PRICE = 20000; // 예시 가격

const sampleDresses = [
  { code: 'No. 01', type: 'MERMAID', sizes: ['44', '55', '66'] },
  { code: 'No. 02', type: 'ALINE', sizes: ['55', '66', '77'] },
  { code: 'No. 03', type: 'BALLGOWN', sizes: ['44', '55', '66', '77'] },
  { code: 'No. 04', type: 'MINI', sizes: ['44', '55', '66'] },
  { code: 'No. 05', type: 'MERMAID', sizes: ['55', '66'] },
  { code: 'No. 06', type: 'ALINE', sizes: ['44', '55', '66', '77'] },
] as const;

const sampleShoes = [
  { nameKo: '포인티드 펌프스', nameEn: 'Pointed pumps', heelCm: 7 },
  { nameKo: '스트랩 샌들', nameEn: 'Strap sandals', heelCm: 5 },
  { nameKo: '새틴 플랫', nameEn: 'Satin flats', heelCm: 1 },
];

const SHOE_SIZES = [220, 225, 230, 235, 240, 245, 250];

async function main() {
  await db
    .insert(schema.dresses)
    .values(
      sampleDresses.map((d, i) => ({
        code: d.code,
        nameKo: d.code,
        nameEn: d.code,
        type: d.type,
        sizes: [...d.sizes],
        priceKrw: SAMPLE_DRESS_PRICE,
        sortOrder: i,
      })),
    )
    .onConflictDoNothing();

  const existing = await db.select().from(schema.shoes).limit(1);
  if (existing.length === 0) {
    for (const [i, s] of sampleShoes.entries()) {
      const [shoe] = await db
        .insert(schema.shoes)
        .values({ ...s, priceKrw: SAMPLE_SHOE_PRICE, sortOrder: i })
        .returning();
      await db.insert(schema.shoeStocks).values(SHOE_SIZES.map((size) => ({ shoeId: shoe.id, size, quantity: 1 })));
    }
  }
  console.log('seed done');
  process.exit(0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
